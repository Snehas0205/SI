from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from django.contrib import messages
from django.core.paginator import Paginator
from .models import *
from career.models import PersonalizedTask, StudentCareerProfile
import qrcode
import io
import base64
import json
import csv
from datetime import datetime, timedelta
from django.db.models import Count, Q

# Authentication Views
def login_view(request):
    # Redirect already logged-in users
    if request.user.is_authenticated:
        return redirect('dashboard')
        
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, 'Logged in successfully')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('home')

# Dashboard Views
@login_required
def dashboard(request):
    user_profile = UserProfile.objects.get_or_create(user=request.user)[0]
    context = {
        'user_profile': user_profile,
        'today': timezone.now().date(),
    }
    
    if user_profile.user_type == 'student':
        # Student dashboard data
        enrolled_subjects = request.user.enrolled_subjects.all()
        recent_attendance = Attendance.objects.filter(student=request.user).order_by('-marked_at')[:5]
        attendance_goals = AttendanceGoal.objects.filter(student=request.user)
        pending_tasks = PersonalizedTask.objects.filter(student=request.user, is_completed=False)[:5]
        
        context.update({
            'enrolled_subjects': enrolled_subjects,
            'recent_attendance': recent_attendance,
            'attendance_goals': attendance_goals,
            'pending_tasks': pending_tasks,
        })
        return render(request, 'student_dashboard.html', context)
        
    elif user_profile.user_type == 'teacher':
        # Teacher dashboard data
        taught_subjects = request.user.taught_subjects.all()
        active_sessions = AttendanceSession.objects.filter(teacher=request.user, is_active=True)
        recent_sessions = AttendanceSession.objects.filter(teacher=request.user).order_by('-start_time')[:5]
        
        context.update({
            'taught_subjects': taught_subjects,
            'active_sessions': active_sessions,
            'recent_sessions': recent_sessions,
        })
        return render(request, 'teacher_dashboard.html', context)
    
    return render(request, 'dashboard.html', context)

# Attendance Session Management
@login_required
def create_session(request):
    if request.method == 'POST':
        subject_id = request.POST.get('subject_id')
        session_type = request.POST.get('session_type', 'qr')
        
        subject = get_object_or_404(Subject, id=subject_id, teacher=request.user)
        
        # Create new attendance session
        session = AttendanceSession.objects.create(
            subject=subject,
            teacher=request.user,
            session_type=session_type,
        )
        
        # Generate QR code data
        if session_type == 'qr':
            qr_data = f"smarttrack://attend/{session.session_id}"
            session.qr_code_data = qr_data
            session.save()
        
        messages.success(request, 'Attendance session created successfully!')
        return redirect('session_detail', session_id=session.session_id)
    
    taught_subjects = request.user.taught_subjects.all()
    return render(request, 'create_session.html', {'subjects': taught_subjects})

@login_required
def session_detail(request, session_id):
    session = get_object_or_404(AttendanceSession, session_id=session_id)
    
    # Check permissions
    if session.teacher != request.user and not request.user.is_superuser:
        messages.error(request, 'You do not have permission to view this session.')
        return redirect('dashboard')
    
    attendances = Attendance.objects.filter(session=session).order_by('student__first_name')
    enrolled_students = session.subject.students.all()
    
    # Generate QR code image
    qr_code_img = None
    if session.qr_code_data:
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(session.qr_code_data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = io.BytesIO()
        img.save(buffer, 'PNG')
        buffer.seek(0)
        qr_code_img = base64.b64encode(buffer.getvalue()).decode()
    
    context = {
        'session': session,
        'attendances': attendances,
        'enrolled_students': enrolled_students,
        'qr_code_img': qr_code_img,
        'attendance_count': attendances.filter(status='present').count(),
        'total_students': enrolled_students.count(),
    }
    
    return render(request, 'session_detail.html', context)

# Attendance Marking
@csrf_exempt
@login_required
def mark_attendance(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        session_id = data.get('session_id')
        student_id = data.get('student_id')
        status = data.get('status', 'present')
        
        try:
            session = AttendanceSession.objects.get(session_id=session_id, is_active=True)
            student = User.objects.get(id=student_id)
            
            # Check if student is enrolled in the subject
            if not session.subject.students.filter(id=student.id).exists():
                return JsonResponse({'success': False, 'error': 'Student not enrolled in this subject'})
            
            # Mark or update attendance
            attendance, created = Attendance.objects.get_or_create(
                session=session,
                student=student,
                defaults={
                    'status': status,
                    'marked_by': request.user,
                }
            )
            
            if not created:
                attendance.status = status
                attendance.marked_by = request.user
                attendance.save()
            
            # Update attendance goal
            goal, _ = AttendanceGoal.objects.get_or_create(
                student=student,
                subject=session.subject
            )
            goal.total_classes += 1 if created else 0
            if status == 'present':
                goal.attended_classes += 1 if created else (1 if attendance.status == 'present' else 0)
            goal.current_percentage = (goal.attended_classes / goal.total_classes * 100) if goal.total_classes > 0 else 0
            goal.save()
            
            return JsonResponse({
                'success': True,
                'message': f'Attendance marked as {status}',
                'attendance_id': attendance.id
            })
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@csrf_exempt
@login_required
def scan_attendance(request):
    """Handle QR code scan attendance"""
    if request.method == 'POST':
        data = json.loads(request.body)
        session_id = data.get('session_id')
        
        try:
            session = AttendanceSession.objects.get(session_id=session_id, is_active=True)
            
            # Check if student is enrolled
            if not session.subject.students.filter(id=request.user.id).exists():
                return JsonResponse({'success': False, 'error': 'You are not enrolled in this subject'})
            
            # Mark attendance
            attendance, created = Attendance.objects.get_or_create(
                session=session,
                student=request.user,
                defaults={
                    'status': 'present',
                    'marked_by': request.user,
                }
            )
            
            if not created:
                return JsonResponse({'success': False, 'error': 'Attendance already marked'})
            
            return JsonResponse({
                'success': True,
                'message': 'Attendance marked successfully!',
                'subject': session.subject.name,
                'time': attendance.marked_at.strftime('%H:%M')
            })
            
        except AttendanceSession.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Invalid or expired session'})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

# Reports and Analytics
@login_required
def attendance_report(request):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    if user_profile.user_type == 'student':
        # Student's personal attendance report
        subjects = request.user.enrolled_subjects.all()
        attendance_data = []
        
        for subject in subjects:
            total_sessions = AttendanceSession.objects.filter(subject=subject).count()
            attended_sessions = Attendance.objects.filter(
                session__subject=subject,
                student=request.user,
                status='present'
            ).count()
            
            percentage = (attended_sessions / total_sessions * 100) if total_sessions > 0 else 0
            
            attendance_data.append({
                'subject': subject,
                'total_sessions': total_sessions,
                'attended_sessions': attended_sessions,
                'percentage': round(percentage, 2)
            })
        
        context = {
            'attendance_data': attendance_data,
            'user_type': 'student'
        }
        
    elif user_profile.user_type == 'teacher':
        # Teacher's class attendance reports
        subjects = request.user.taught_subjects.all()
        subject_id = request.GET.get('subject')
        
        if subject_id:
            selected_subject = get_object_or_404(Subject, id=subject_id, teacher=request.user)
            sessions = AttendanceSession.objects.filter(subject=selected_subject).order_by('-start_time')
            
            context = {
                'subjects': subjects,
                'selected_subject': selected_subject,
                'sessions': sessions,
                'user_type': 'teacher'
            }
        else:
            context = {
                'subjects': subjects,
                'user_type': 'teacher'
            }
    
    return render(request, 'reports.html', context)

# QR Scanner for Students
@login_required
def qr_scanner(request):
    """QR code scanner page for students"""
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    if user_profile.user_type != 'student':
        messages.error(request, 'QR scanner is only available for students.')
        return redirect('dashboard')
    
    return render(request, 'qr_scanner.html')

# Recent attendance API
@login_required
def recent_attendance_api(request):
    """API endpoint to get recent attendance for the current user"""
    recent_attendance = Attendance.objects.filter(
        student=request.user
    ).select_related('session__subject').order_by('-marked_at')[:5]
    
    data = []
    for attendance in recent_attendance:
        data.append({
            'subject': attendance.session.subject.code,
            'time': attendance.marked_at.strftime('%m/%d %H:%M'),
            'status': attendance.status
        })
    
    return JsonResponse(data, safe=False)

# Marks Dashboard
@login_required
def marks_dashboard(request):
    """Display student marks and grades"""
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    if user_profile.user_type == 'student':
        # Student view - their own marks
        subjects = request.user.enrolled_subjects.all()
        marks_data = []
        
        for subject in subjects:
            student_marks = StudentMark.objects.filter(
                student=request.user,
                exam__subject=subject
            ).select_related('exam')
            
            total_marks = sum(mark.marks_obtained for mark in student_marks)
            total_possible = sum(mark.exam.total_marks for mark in student_marks)
            average = (total_marks / total_possible * 100) if total_possible > 0 else 0
            
            marks_data.append({
                'subject': subject,
                'marks': student_marks,
                'average': average,
                'total_marks': total_marks,
                'total_possible': total_possible
            })
    
    elif user_profile.user_type == 'teacher':
        # Teacher view - their subjects' marks
        subjects = request.user.taught_subjects.all()
        marks_data = []
        
        for subject in subjects:
            exams = Exam.objects.filter(subject=subject, created_by=request.user)
            marks_data.append({
                'subject': subject,
                'exams': exams,
                'total_students': subject.students.count()
            })
    
    else:
        marks_data = []
    
    context = {
        'marks_data': marks_data,
        'user_type': user_profile.user_type
    }
    
    return render(request, 'marks_dashboard.html', context)

@login_required
def subject_marks(request, subject_id):
    """Detailed marks view for a specific subject"""
    subject = get_object_or_404(Subject, id=subject_id)
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    if user_profile.user_type == 'student':
        if not subject.students.filter(id=request.user.id).exists():
            messages.error(request, 'You are not enrolled in this subject.')
            return redirect('attendance:marks')
        
        marks = StudentMark.objects.filter(
            student=request.user,
            exam__subject=subject
        ).select_related('exam').order_by('-exam__date')
        
    elif user_profile.user_type == 'teacher':
        if subject.teacher != request.user:
            messages.error(request, 'You do not have permission to view this subject.')
            return redirect('attendance:marks')
        
        marks = StudentMark.objects.filter(
            exam__subject=subject
        ).select_related('student', 'exam').order_by('-exam__date', 'student__username')
    
    context = {
        'subject': subject,
        'marks': marks,
        'user_type': user_profile.user_type
    }
    
    return render(request, 'subject_marks.html', context)

# Activities Dashboard
@login_required
def activities_dashboard(request):
    """Display extracurricular activities"""
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    if user_profile.user_type == 'student':
        # Student view - available and registered activities
        registered_activities = StudentActivity.objects.filter(
            student=request.user
        ).select_related('activity')
        
        available_activities = ExtracurricularActivity.objects.filter(
            date_start__gte=timezone.now().date()
        ).exclude(
            id__in=registered_activities.values_list('activity_id', flat=True)
        )
        
        context = {
            'registered_activities': registered_activities,
            'available_activities': available_activities,
            'user_type': 'student'
        }
    
    else:
        # Teacher/Admin view - all activities
        activities = ExtracurricularActivity.objects.all().order_by('-date_start')
        context = {
            'activities': activities,
            'user_type': user_profile.user_type
        }
    
    return render(request, 'activities_dashboard.html', context)

@csrf_exempt
@login_required
def register_activity(request, activity_id):
    """Register student for an extracurricular activity"""
    if request.method == 'POST':
        user_profile = get_object_or_404(UserProfile, user=request.user)
        
        if user_profile.user_type != 'student':
            return JsonResponse({'success': False, 'error': 'Only students can register for activities'})
        
        try:
            activity = ExtracurricularActivity.objects.get(id=activity_id)
            
            # Check if already registered
            if StudentActivity.objects.filter(student=request.user, activity=activity).exists():
                return JsonResponse({'success': False, 'error': 'Already registered for this activity'})
            
            # Check if activity is still open
            if activity.date_start < timezone.now().date():
                return JsonResponse({'success': False, 'error': 'Registration closed for this activity'})
            
            # Check capacity
            if activity.max_participants:
                current_participants = StudentActivity.objects.filter(activity=activity).count()
                if current_participants >= activity.max_participants:
                    return JsonResponse({'success': False, 'error': 'Activity is full'})
            
            # Register student
            StudentActivity.objects.create(
                student=request.user,
                activity=activity,
                status='registered'
            )
            
            return JsonResponse({
                'success': True,
                'message': f'Successfully registered for {activity.name}'
            })
            
        except ExtracurricularActivity.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Activity not found'})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

# CSV Export Views
@login_required
def export_marks_csv(request, subject_id):
    """Export marks for a specific subject to CSV"""
    subject = get_object_or_404(Subject, id=subject_id)
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    # Check permissions
    if user_profile.user_type == 'student':
        if not subject.students.filter(id=request.user.id).exists():
            messages.error(request, 'You are not enrolled in this subject.')
            return redirect('attendance:marks')
        marks = StudentMark.objects.filter(
            student=request.user,
            exam__subject=subject
        ).select_related('exam').order_by('-exam__date')
    elif user_profile.user_type == 'teacher':
        if subject.teacher != request.user:
            messages.error(request, 'You do not have permission to export this subject.')
            return redirect('attendance:marks')
        marks = StudentMark.objects.filter(
            exam__subject=subject
        ).select_related('student', 'exam').order_by('-exam__date', 'student__username')
    else:
        return redirect('attendance:marks')
    
    # Create the HttpResponse object with CSV header
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{subject.code}_marks.csv"'
    
    writer = csv.writer(response)
    
    # Write header row
    if user_profile.user_type == 'teacher':
        writer.writerow([
            'Student Name', 'Student ID', 'Exam Name', 'Exam Type', 'Exam Date',
            'Marks Obtained', 'Total Marks', 'Percentage', 'Grade', 'Performance', 'Feedback'
        ])
    else:
        writer.writerow([
            'Exam Name', 'Exam Type', 'Exam Date',
            'Marks Obtained', 'Total Marks', 'Percentage', 'Grade', 'Performance', 'Feedback'
        ])
    
    # Write data rows
    for mark in marks:
        percentage = mark.get_percentage()
        grade = mark.get_grade()
        performance = mark.get_performance_status()
        
        if user_profile.user_type == 'teacher':
            writer.writerow([
                mark.student.get_full_name(),
                mark.student.username,
                mark.exam.name,
                mark.exam.get_exam_type_display(),
                mark.exam.date.strftime('%Y-%m-%d'),
                mark.marks_obtained,
                mark.exam.total_marks,
                f'{percentage:.1f}%',
                grade,
                performance,
                mark.feedback or 'N/A'
            ])
        else:
            writer.writerow([
                mark.exam.name,
                mark.exam.get_exam_type_display(),
                mark.exam.date.strftime('%Y-%m-%d'),
                mark.marks_obtained,
                mark.exam.total_marks,
                f'{percentage:.1f}%',
                grade,
                performance,
                mark.feedback or 'N/A'
            ])
    
    return response

@login_required
def export_attendance_csv(request):
    """Export attendance data to CSV"""
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    if user_profile.user_type == 'student':
        # Student's own attendance
        attendance_records = Attendance.objects.filter(
            student=request.user
        ).select_related('session__subject', 'marked_by').order_by('-marked_at')
        filename = f'{request.user.username}_attendance.csv'
    elif user_profile.user_type == 'teacher':
        # All attendance for teacher's subjects
        attendance_records = Attendance.objects.filter(
            session__subject__teacher=request.user
        ).select_related('student', 'session__subject', 'marked_by').order_by('-marked_at')
        filename = f'{request.user.username}_class_attendance.csv'
    else:
        return redirect('dashboard')
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    
    writer = csv.writer(response)
    
    # Write header
    if user_profile.user_type == 'teacher':
        writer.writerow([
            'Student Name', 'Student ID', 'Subject Code', 'Subject Name',
            'Session Date', 'Status', 'Marked By', 'Notes'
        ])
    else:
        writer.writerow([
            'Subject Code', 'Subject Name', 'Session Date', 'Status', 'Marked By', 'Notes'
        ])
    
    # Write data
    for attendance in attendance_records:
        if user_profile.user_type == 'teacher':
            writer.writerow([
                attendance.student.get_full_name(),
                attendance.student.username,
                attendance.session.subject.code,
                attendance.session.subject.name,
                attendance.session.start_time.strftime('%Y-%m-%d %H:%M'),
                attendance.get_status_display(),
                attendance.marked_by.get_full_name(),
                attendance.notes or 'N/A'
            ])
        else:
            writer.writerow([
                attendance.session.subject.code,
                attendance.session.subject.name,
                attendance.session.start_time.strftime('%Y-%m-%d %H:%M'),
                attendance.get_status_display(),
                attendance.marked_by.get_full_name(),
                attendance.notes or 'N/A'
            ])
    
    return response

# Home page
def home(request):
    # Always show landing page - users can navigate to dashboard via menu
    return render(request, 'landing.html')

# About page
def about_view(request):
    return render(request, 'about.html')

# Contact page
def contact_view(request):
    if request.method == 'POST':
        # Handle contact form submission
        try:
            name = request.POST.get('name', '').strip()
            email = request.POST.get('email', '').strip()
            role = request.POST.get('role', '').strip()
            subject = request.POST.get('subject', '').strip()
            message = request.POST.get('message', '').strip()
            
            # Basic validation
            if not all([name, email, subject, message]):
                messages.error(request, 'Please fill in all required fields.')
                return render(request, 'contact.html')
            
            # Email validation
            import re
            email_pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
            if not re.match(email_pattern, email):
                messages.error(request, 'Please enter a valid email address.')
                return render(request, 'contact.html')
            
            # In production, you would save to database or send email
            # For now, just log the contact attempt
            import logging
            logger = logging.getLogger('attendance')
            logger.info(f'Contact form submission: {name} ({email}) - {subject}')
            
            messages.success(request, 'Thank you for your message! We\'ll get back to you soon.')
            return redirect('contact')
            
        except Exception as e:
            messages.error(request, 'An error occurred while sending your message. Please try again.')
            import logging
            logger = logging.getLogger('attendance')
            logger.error(f'Contact form error: {str(e)}')
            
    return render(request, 'contact.html')

# WiFi Proximity Attendance Views
@login_required
@csrf_exempt
def wifi_active_session(request):
    """Check for active WiFi-enabled attendance sessions"""
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        
        if user_profile.user_type == 'student':
            active_session = AttendanceSession.objects.filter(
                subject__students=request.user,
                is_active=True,
                wifi_enabled=True,
                session_type='wifi'
            ).first()
            
            if active_session:
                return JsonResponse({
                    'active_session': True,
                    'session': {
                        'session_id': str(active_session.session_id),
                        'subject_name': active_session.subject.name,
                        'proximity_range': active_session.proximity_range,
                        'wifi_ssid': active_session.wifi_ssid,
                    }
                })
        
        return JsonResponse({'active_session': False})
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required
@csrf_exempt
def wifi_mark_attendance(request):
    """Mark attendance via WiFi proximity"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            session_id = data.get('session_id')
            wifi_data = data.get('wifi_data', {})
            
            session = AttendanceSession.objects.get(
                session_id=session_id,
                is_active=True,
                wifi_enabled=True
            )
            
            if not session.subject.students.filter(id=request.user.id).exists():
                return JsonResponse({'success': False, 'error': 'Not enrolled in this subject'})
            
            existing = Attendance.objects.filter(
                session=session,
                student=request.user
            ).first()
            
            if existing:
                return JsonResponse({'success': False, 'error': 'Attendance already marked'})
            
            distance = wifi_data.get('distance', 999)
            if distance > session.proximity_range:
                return JsonResponse({'success': False, 'error': 'Too far from classroom'})
            
            attendance = Attendance.objects.create(
                session=session,
                student=request.user,
                status='present',
                marked_by=request.user,
                notes=f"WiFi proximity: {wifi_data.get('network_name', 'Unknown')} - {distance:.1f}m"
            )
            
            goal, _ = AttendanceGoal.objects.get_or_create(
                student=request.user,
                subject=session.subject
            )
            goal.total_classes += 1
            goal.attended_classes += 1
            goal.current_percentage = (goal.attended_classes / goal.total_classes * 100)
            goal.save()
            
            import logging
            logger = logging.getLogger('attendance')
            logger.info(f'WiFi attendance: {request.user.username} - {session.subject.code} - {distance}m')
            
            return JsonResponse({
                'success': True,
                'message': 'Attendance marked via WiFi proximity',
                'attendance_id': attendance.id
            })
            
        except AttendanceSession.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Invalid or inactive session'})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

