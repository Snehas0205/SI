from django.urls import path
from . import views

app_name = 'attendance'

urlpatterns = [
    # Session management
    path('create-session/', views.create_session, name='create_session'),
    path('session/<uuid:session_id>/', views.session_detail, name='session_detail'),
    
    # Attendance marking
    path('mark-attendance/', views.mark_attendance, name='mark_attendance'),
    path('scan-attendance/', views.scan_attendance, name='scan_attendance'),
    path('qr-scanner/', views.qr_scanner, name='qr_scanner'),
    
    # Reports
    path('reports/', views.attendance_report, name='reports'),
    path('recent-attendance/', views.recent_attendance_api, name='recent_attendance_api'),
    
    # Marks and Grades
    path('marks/', views.marks_dashboard, name='marks'),
    path('marks/subject/<int:subject_id>/', views.subject_marks, name='subject_marks'),
    
    # Extracurricular Activities
    path('activities/', views.activities_dashboard, name='activities'),
    path('activities/register/<int:activity_id>/', views.register_activity, name='register_activity'),
    
    # CSV Export
    path('export-marks-csv/<int:subject_id>/', views.export_marks_csv, name='export_marks_csv'),
    path('export-attendance-csv/', views.export_attendance_csv, name='export_attendance_csv'),
]
