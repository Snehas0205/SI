from django.contrib import admin
from .models import *

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'user_type', 'student_id', 'phone', 'created_at']
    list_filter = ['user_type', 'created_at']
    search_fields = ['user__username', 'user__email', 'student_id']
    readonly_fields = ['created_at']

@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ['code', 'name', 'teacher', 'created_at']
    list_filter = ['teacher', 'created_at']
    search_fields = ['code', 'name', 'teacher__username']
    filter_horizontal = ['students']
    readonly_fields = ['created_at']

@admin.register(ClassSchedule)
class ClassScheduleAdmin(admin.ModelAdmin):    
    list_display = ['subject', 'day_of_week', 'start_time', 'end_time', 'room_number', 'is_active']
    list_filter = ['day_of_week', 'is_active', 'subject__teacher']
    search_fields = ['subject__code', 'subject__name', 'room_number']
    list_editable = ['is_active']

@admin.register(AttendanceSession)
class AttendanceSessionAdmin(admin.ModelAdmin):
    list_display = ['subject', 'teacher', 'session_type', 'start_time', 'end_time', 'is_active']
    list_filter = ['session_type', 'is_active', 'start_time', 'teacher']
    search_fields = ['subject__code', 'subject__name', 'teacher__username']
    readonly_fields = ['session_id', 'qr_code_data']
    list_editable = ['is_active']

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ['student', 'session', 'status', 'marked_at', 'marked_by']
    list_filter = ['status', 'marked_at', 'session__subject', 'session__teacher']
    search_fields = ['student__username', 'session__subject__code']
    readonly_fields = ['marked_at']
    list_editable = ['status']

@admin.register(AttendanceGoal)
class AttendanceGoalAdmin(admin.ModelAdmin):
    list_display = ['student', 'subject', 'target_percentage', 'current_percentage', 'total_classes', 'attended_classes']
    list_filter = ['subject', 'created_at']
    search_fields = ['student__username', 'subject__code']
    readonly_fields = ['created_at', 'updated_at']

@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ['name', 'subject', 'exam_type', 'total_marks', 'date', 'created_by']
    list_filter = ['exam_type', 'subject', 'date', 'created_by']
    search_fields = ['name', 'subject__code', 'subject__name']
    readonly_fields = ['created_at']
    date_hierarchy = 'date'

@admin.register(StudentMark)
class StudentMarkAdmin(admin.ModelAdmin):
    list_display = ['student', 'exam', 'marks_obtained', 'get_percentage', 'get_grade', 'graded_by', 'graded_at']
    list_filter = ['exam__subject', 'exam__exam_type', 'graded_by', 'graded_at']
    search_fields = ['student__username', 'exam__name']
    readonly_fields = ['get_percentage', 'get_grade', 'graded_at']
    
    def get_percentage(self, obj):
        return f"{obj.get_percentage():.1f}%"
    get_percentage.short_description = 'Percentage'
    
    def get_grade(self, obj):
        return obj.get_grade()
    get_grade.short_description = 'Grade'

@admin.register(ExtracurricularActivity)
class ExtracurricularActivityAdmin(admin.ModelAdmin):
    list_display = ['name', 'activity_type', 'date_start', 'date_end', 'location', 'max_participants']
    list_filter = ['activity_type', 'date_start']
    search_fields = ['name', 'description', 'location', 'organizer']
    date_hierarchy = 'date_start'

@admin.register(StudentActivity)
class StudentActivityAdmin(admin.ModelAdmin):
    list_display = ['student', 'activity', 'status', 'hours_contributed', 'registered_at']
    list_filter = ['status', 'activity__activity_type', 'registered_at']
    search_fields = ['student__username', 'activity__name']
    readonly_fields = ['registered_at', 'updated_at']
