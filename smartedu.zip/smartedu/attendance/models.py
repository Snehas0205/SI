from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import uuid

class UserProfile(models.Model):
    USER_TYPES = [
        ('student', 'Student'),
        ('teacher', 'Teacher'),
        ('admin', 'Admin'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    user_type = models.CharField(max_length=10, choices=USER_TYPES)
    student_id = models.CharField(max_length=20, blank=True, null=True)
    phone = models.CharField(max_length=15, blank=True)
    profile_picture = models.ImageField(upload_to='profiles/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.user_type}"

class Subject(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=10, unique=True)
    description = models.TextField(blank=True)
    teacher = models.ForeignKey(User, on_delete=models.CASCADE, related_name='taught_subjects')
    students = models.ManyToManyField(User, related_name='enrolled_subjects')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.code} - {self.name}"

class ClassSchedule(models.Model):
    DAYS_OF_WEEK = [
        ('monday', 'Monday'),
        ('tuesday', 'Tuesday'),
        ('wednesday', 'Wednesday'),
        ('thursday', 'Thursday'),
        ('friday', 'Friday'),
        ('saturday', 'Saturday'),
        ('sunday', 'Sunday'),
    ]
    
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    day_of_week = models.CharField(max_length=10, choices=DAYS_OF_WEEK)
    start_time = models.TimeField()
    end_time = models.TimeField()
    room_number = models.CharField(max_length=20)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.subject.code} - {self.day_of_week} {self.start_time}"

class AttendanceSession(models.Model):
    SESSION_TYPES = [
        ('qr', 'QR Code'),
        ('manual', 'Manual Entry'),
        ('biometric', 'Biometric'),
        ('nfc', 'NFC'),
        ('wifi', 'WiFi Proximity'),
    ]
    
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    teacher = models.ForeignKey(User, on_delete=models.CASCADE)
    session_id = models.UUIDField(default=uuid.uuid4, unique=True)
    session_type = models.CharField(max_length=10, choices=SESSION_TYPES, default='qr')
    start_time = models.DateTimeField(default=timezone.now)
    end_time = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    qr_code_data = models.TextField(blank=True, null=True)
    # WiFi proximity fields
    wifi_ssid = models.CharField(max_length=100, blank=True, null=True, help_text="WiFi network name for proximity detection")
    proximity_range = models.IntegerField(default=50, help_text="Detection range in meters")
    wifi_enabled = models.BooleanField(default=False, help_text="Enable WiFi proximity attendance")
    location_data = models.JSONField(blank=True, null=True)  # For WiFi/Bluetooth location
    
    def __str__(self):
        return f"{self.subject.code} - {self.start_time.strftime('%Y-%m-%d %H:%M')}"

class Attendance(models.Model):
    ATTENDANCE_STATUS = [
        ('present', 'Present'),
        ('late', 'Late'),
        ('absent', 'Absent'),
    ]
    
    session = models.ForeignKey(AttendanceSession, on_delete=models.CASCADE)
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=ATTENDANCE_STATUS)
    marked_at = models.DateTimeField(auto_now_add=True)
    marked_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='marked_attendance')
    notes = models.TextField(blank=True)
    
    class Meta:
        unique_together = ['session', 'student']
    
    def __str__(self):
        return f"{self.student.username} - {self.session.subject.code} - {self.status}"

class AttendanceGoal(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    target_percentage = models.FloatField(default=75.0)
    current_percentage = models.FloatField(default=0.0)
    total_classes = models.IntegerField(default=0)
    attended_classes = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['student', 'subject']
    
    def __str__(self):
        return f"{self.student.username} - {self.subject.code} Goal: {self.target_percentage}%"

class Exam(models.Model):
    EXAM_TYPES = [
        ('quiz', 'Quiz'),
        ('midterm', 'Midterm'),
        ('final', 'Final Exam'),
        ('assignment', 'Assignment'),
        ('project', 'Project'),
        ('presentation', 'Presentation'),
    ]
    
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    exam_type = models.CharField(max_length=20, choices=EXAM_TYPES)
    total_marks = models.FloatField()
    date = models.DateField()
    description = models.TextField(blank=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_exams')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.subject.code} - {self.name}"

class StudentMark(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE)
    marks_obtained = models.FloatField()
    feedback = models.TextField(blank=True)
    graded_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='graded_marks')
    graded_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['student', 'exam']
    
    def get_percentage(self):
        return (self.marks_obtained / self.exam.total_marks * 100) if self.exam.total_marks > 0 else 0
    
    def get_grade(self):
        percentage = self.get_percentage()
        if percentage >= 90:
            return 'A+'
        elif percentage >= 80:
            return 'A'
        elif percentage >= 70:
            return 'B'
        elif percentage >= 60:
            return 'C'
        elif percentage >= 50:
            return 'D'
        else:
            return 'F'
    
    def get_performance_status(self):
        percentage = self.get_percentage()
        if percentage >= 90:
            return 'Excellent'
        elif percentage >= 80:
            return 'Good'
        elif percentage >= 70:
            return 'Average'
        elif percentage >= 60:
            return 'Poor'
        else:
            return 'Failing'
    
    @property
    def marked_at(self):
        return self.graded_at
    
    def __str__(self):
        return f"{self.student.username} - {self.exam.name} - {self.marks_obtained}/{self.exam.total_marks}"

class ExtracurricularActivity(models.Model):
    ACTIVITY_TYPES = [
        ('sports', 'Sports'),
        ('cultural', 'Cultural'),
        ('academic', 'Academic Club'),
        ('volunteer', 'Volunteer Work'),
        ('leadership', 'Leadership'),
        ('competition', 'Competition'),
        ('workshop', 'Workshop/Seminar'),
    ]
    
    name = models.CharField(max_length=200)
    activity_type = models.CharField(max_length=20, choices=ACTIVITY_TYPES)
    description = models.TextField()
    date_start = models.DateField()
    date_end = models.DateField(null=True, blank=True)
    location = models.CharField(max_length=200, blank=True)
    organizer = models.CharField(max_length=200, blank=True)
    max_participants = models.IntegerField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.name} ({self.get_activity_type_display()})"

class StudentActivity(models.Model):
    PARTICIPATION_STATUS = [
        ('registered', 'Registered'),
        ('participated', 'Participated'),
        ('completed', 'Completed'),
        ('winner', 'Winner'),
        ('runner_up', 'Runner Up'),
        ('cancelled', 'Cancelled'),
    ]
    
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    activity = models.ForeignKey(ExtracurricularActivity, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=PARTICIPATION_STATUS, default='registered')
    achievement = models.TextField(blank=True, help_text="Any special achievement or recognition")
    hours_contributed = models.FloatField(default=0, help_text="Hours spent on this activity")
    certificate_url = models.URLField(blank=True, help_text="Link to certificate or proof")
    registered_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['student', 'activity']
        verbose_name_plural = 'Student Activities'
    
    def __str__(self):
        return f"{self.student.username} - {self.activity.name} ({self.status})"
