from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from attendance.models import *
from career.models import *
from django.utils import timezone
from datetime import timedelta

class Command(BaseCommand):
    help = 'Populate the database with sample data'

    def handle(self, *args, **options):
        self.stdout.write('Creating sample data...')

        # Create sample users
        if not User.objects.filter(username='student').exists():
            student_user = User.objects.create_user(
                username='student',
                email='student@smarttrack.com',
                password='password123',
                first_name='John',
                last_name='Doe'
            )
            UserProfile.objects.create(
                user=student_user,
                user_type='student',
                student_id='ST2024001',
                phone='+1234567890'
            )
            self.stdout.write('Created student user')

        if not User.objects.filter(username='teacher').exists():
            teacher_user = User.objects.create_user(
                username='teacher',
                email='teacher@smarttrack.com',
                password='password123',
                first_name='Jane',
                last_name='Smith'
            )
            UserProfile.objects.create(
                user=teacher_user,
                user_type='teacher',
                phone='+1234567891'
            )
            self.stdout.write('Created teacher user')

        # Set admin password
        try:
            admin_user = User.objects.get(username='admin')
            admin_user.set_password('admin123')
            admin_user.save()
            UserProfile.objects.get_or_create(
                user=admin_user,
                defaults={'user_type': 'admin'}
            )
            self.stdout.write('Set admin password')
        except User.DoesNotExist:
            pass

        # Get users for further operations
        student = User.objects.get(username='student')
        teacher = User.objects.get(username='teacher')

        # Create sample subjects
        subjects_data = [
            {'code': 'CS101', 'name': 'Introduction to Computer Science'},
            {'code': 'MATH201', 'name': 'Advanced Mathematics'},
            {'code': 'ENG101', 'name': 'English Literature'},
            {'code': 'PHYS201', 'name': 'Physics II'},
        ]

        for subject_data in subjects_data:
            subject, created = Subject.objects.get_or_create(
                code=subject_data['code'],
                defaults={
                    'name': subject_data['name'],
                    'teacher': teacher,
                    'description': f'Description for {subject_data["name"]}'
                }
            )
            if created:
                subject.students.add(student)
                self.stdout.write(f'Created subject: {subject.code}')

        # Create sample schedules
        subjects = Subject.objects.all()
        days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
        times = [
            ('09:00', '10:30'),
            ('10:45', '12:15'),
            ('14:00', '15:30'),
            ('15:45', '17:15')
        ]

        for i, subject in enumerate(subjects[:4]):
            ClassSchedule.objects.get_or_create(
                subject=subject,
                day_of_week=days[i % len(days)],
                defaults={
                    'start_time': times[i % len(times)][0],
                    'end_time': times[i % len(times)][1],
                    'room_number': f'Room {101 + i}',
                    'is_active': True
                }
            )

        # Create career paths
        career_paths_data = [
            {'name': 'Software Developer', 'description': 'Build applications and systems', 'icon': 'code', 'color': '#3b82f6'},
            {'name': 'Data Scientist', 'description': 'Analyze data to derive insights', 'icon': 'chart-bar', 'color': '#10b981'},
            {'name': 'Product Manager', 'description': 'Lead product development', 'icon': 'briefcase', 'color': '#f59e0b'},
            {'name': 'UX Designer', 'description': 'Design user experiences', 'icon': 'paint-brush', 'color': '#ef4444'},
        ]

        for career_data in career_paths_data:
            CareerPath.objects.get_or_create(
                name=career_data['name'],
                defaults=career_data
            )

        # Create skills
        skills_data = [
            {'name': 'Python Programming', 'category': 'technical'},
            {'name': 'JavaScript', 'category': 'technical'},
            {'name': 'Communication', 'category': 'soft'},
            {'name': 'Problem Solving', 'category': 'soft'},
            {'name': 'Mathematics', 'category': 'academic'},
            {'name': 'Statistics', 'category': 'academic'},
        ]

        for skill_data in skills_data:
            Skill.objects.get_or_create(
                name=skill_data['name'],
                defaults=skill_data
            )

        # Create student career profile
        career_profile, created = StudentCareerProfile.objects.get_or_create(
            student=student,
            defaults={
                'career_goal': 'Become a full-stack software developer',
                'graduation_year': 2025
            }
        )

        if created:
            # Add interested careers
            sw_dev = CareerPath.objects.get(name='Software Developer')
            career_profile.interested_careers.add(sw_dev)

        # Create sample tasks
        sample_tasks = [
            {
                'title': 'Complete Python Exercise',
                'description': 'Work through the Python programming exercises from Chapter 5',
                'task_type': 'study',
                'priority': 'high',
                'estimated_duration': 45,
            },
            {
                'title': 'Review Data Structures',
                'description': 'Go through arrays, linked lists, and trees concepts',
                'task_type': 'skill_building',
                'priority': 'medium',
                'estimated_duration': 30,
            },
            {
                'title': 'Research Tech Companies',
                'description': 'Look into potential internship opportunities',
                'task_type': 'career_exploration',
                'priority': 'low',
                'estimated_duration': 60,
            }
        ]

        for task_data in sample_tasks:
            PersonalizedTask.objects.get_or_create(
                student=student,
                title=task_data['title'],
                defaults=task_data
            )

        # Create attendance goals
        for subject in Subject.objects.filter(students=student):
            AttendanceGoal.objects.get_or_create(
                student=student,
                subject=subject,
                defaults={
                    'target_percentage': 85.0,
                    'current_percentage': 78.5,
                    'total_classes': 20,
                    'attended_classes': 16,
                }
            )

        # Create sample attendance session
        cs_subject = Subject.objects.get(code='CS101')
        session, created = AttendanceSession.objects.get_or_create(
            subject=cs_subject,
            teacher=teacher,
            defaults={
                'session_type': 'qr',
                'start_time': timezone.now() - timedelta(hours=2),
                'is_active': True,
                'qr_code_data': f'smarttrack://attend/{cs_subject.code}-{timezone.now().date()}'
            }
        )

        # Create sample attendance record
        Attendance.objects.get_or_create(
            session=session,
            student=student,
            defaults={
                'status': 'present',
                'marked_by': student,
            }
        )

        self.stdout.write(
            self.style.SUCCESS('Successfully populated database with sample data!')
        )
        self.stdout.write('Login credentials:')
        self.stdout.write('Admin: admin / admin123')
        self.stdout.write('Teacher: teacher / password123')
        self.stdout.write('Student: student / password123')