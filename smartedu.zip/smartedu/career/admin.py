from django.contrib import admin
from .models import *

@admin.register(CareerPath)
class CareerPathAdmin(admin.ModelAdmin):
    list_display = ['name', 'icon', 'color', 'is_active', 'created_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['name', 'description']
    list_editable = ['is_active']
    readonly_fields = ['created_at']

@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    list_display = ['name', 'category']
    list_filter = ['category']
    search_fields = ['name', 'description']
    filter_horizontal = ['career_paths']

@admin.register(StudentCareerProfile)
class StudentCareerProfileAdmin(admin.ModelAdmin):
    list_display = ['student', 'graduation_year', 'created_at', 'updated_at']
    list_filter = ['graduation_year', 'created_at']
    search_fields = ['student__username', 'career_goal']
    filter_horizontal = ['interested_careers']
    readonly_fields = ['created_at', 'updated_at']

@admin.register(StudentSkill)
class StudentSkillAdmin(admin.ModelAdmin):
    list_display = ['student_profile', 'skill', 'proficiency_level', 'acquired_date']
    list_filter = ['proficiency_level', 'acquired_date', 'skill__category']
    search_fields = ['student_profile__student__username', 'skill__name']
    list_editable = ['proficiency_level']
    readonly_fields = ['acquired_date']

@admin.register(PersonalizedTask)
class PersonalizedTaskAdmin(admin.ModelAdmin):
    list_display = ['student', 'title', 'task_type', 'priority', 'estimated_duration', 'is_completed', 'created_at']
    list_filter = ['task_type', 'priority', 'is_completed', 'created_at']
    search_fields = ['student__username', 'title', 'description']
    list_editable = ['priority', 'is_completed']
    readonly_fields = ['created_at']

@admin.register(CareerResource)
class CareerResourceAdmin(admin.ModelAdmin):
    list_display = ['title', 'resource_type', 'is_free', 'rating', 'created_at']
    list_filter = ['resource_type', 'is_free', 'rating', 'created_at']
    search_fields = ['title', 'description']
    filter_horizontal = ['career_paths', 'skills']
    readonly_fields = ['created_at']

@admin.register(FreeTimeActivity)
class FreeTimeActivityAdmin(admin.ModelAdmin):
    list_display = ['student', 'start_time', 'end_time', 'productivity_score', 'created_at']
    list_filter = ['productivity_score', 'created_at']
    search_fields = ['student__username', 'actual_activity']
    readonly_fields = ['created_at']

@admin.register(AchievementBadge)
class AchievementBadgeAdmin(admin.ModelAdmin):
    list_display = ['name', 'icon', 'color']
    search_fields = ['name', 'description']

@admin.register(StudentAchievement)
class StudentAchievementAdmin(admin.ModelAdmin):
    list_display = ['student', 'badge', 'earned_date']
    list_filter = ['badge', 'earned_date']
    search_fields = ['student__username', 'badge__name']
    readonly_fields = ['earned_date']
