from django.urls import path
from . import views

app_name = 'career'

urlpatterns = [
    # Career guidance dashboard
    path('', views.career_dashboard, name='dashboard'),
    path('profile/', views.career_profile, name='profile'),
    path('add-skill/', views.add_skill, name='add_skill'),
    
    # Task management
    path('tasks/', views.task_management, name='tasks'),
    path('complete-task/', views.complete_task, name='complete_task'),
    
    # Free time tracking
    path('free-time/', views.free_time_tracker, name='free_time'),
    path('log-activity/', views.log_free_time_activity, name='log_activity'),
]