from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class CareerPath(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    icon = models.CharField(max_length=50, default='career')  # Font Awesome icon name
    color = models.CharField(max_length=7, default='#007bff')  # Hex color code
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name

class Skill(models.Model):
    SKILL_CATEGORIES = [
        ('technical', 'Technical'),
        ('soft', 'Soft Skills'),
        ('academic', 'Academic'),
        ('creative', 'Creative'),
    ]
    
    name = models.CharField(max_length=100)
    category = models.CharField(max_length=10, choices=SKILL_CATEGORIES)
    description = models.TextField(blank=True)
    career_paths = models.ManyToManyField(CareerPath, related_name='required_skills')
    
    def __str__(self):
        return f"{self.name} ({self.category})"

class StudentCareerProfile(models.Model):
    student = models.OneToOneField(User, on_delete=models.CASCADE)
    interested_careers = models.ManyToManyField(CareerPath, blank=True)
    current_skills = models.ManyToManyField(Skill, through='StudentSkill', blank=True)
    career_goal = models.TextField(blank=True)
    graduation_year = models.IntegerField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.student.username} - Career Profile"

class StudentSkill(models.Model):
    PROFICIENCY_LEVELS = [
        (1, 'Beginner'),
        (2, 'Basic'),
        (3, 'Intermediate'),
        (4, 'Advanced'),
        (5, 'Expert'),
    ]
    
    student_profile = models.ForeignKey(StudentCareerProfile, on_delete=models.CASCADE)
    skill = models.ForeignKey(Skill, on_delete=models.CASCADE)
    proficiency_level = models.IntegerField(choices=PROFICIENCY_LEVELS, default=1)
    acquired_date = models.DateField(auto_now_add=True)
    
    class Meta:
        unique_together = ['student_profile', 'skill']
    
    def __str__(self):
        return f"{self.student_profile.student.username} - {self.skill.name} (Level {self.proficiency_level})"

class PersonalizedTask(models.Model):
    TASK_TYPES = [
        ('study', 'Study Task'),
        ('project', 'Project'),
        ('skill_building', 'Skill Building'),
        ('career_exploration', 'Career Exploration'),
        ('networking', 'Networking'),
    ]
    
    PRIORITY_LEVELS = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    ]
    
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    description = models.TextField()
    task_type = models.CharField(max_length=20, choices=TASK_TYPES)
    priority = models.CharField(max_length=10, choices=PRIORITY_LEVELS, default='medium')
    estimated_duration = models.IntegerField(help_text="Duration in minutes")
    due_date = models.DateTimeField(null=True, blank=True)
    is_completed = models.BooleanField(default=False)
    completed_at = models.DateTimeField(null=True, blank=True)
    related_subject = models.ForeignKey('attendance.Subject', on_delete=models.SET_NULL, null=True, blank=True)
    related_career = models.ForeignKey(CareerPath, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.student.username} - {self.title}"

class CareerResource(models.Model):
    RESOURCE_TYPES = [
        ('article', 'Article'),
        ('video', 'Video'),
        ('course', 'Course'),
        ('book', 'Book'),
        ('website', 'Website'),
        ('tool', 'Tool'),
    ]
    
    title = models.CharField(max_length=200)
    description = models.TextField()
    resource_type = models.CharField(max_length=10, choices=RESOURCE_TYPES)
    url = models.URLField(blank=True)
    career_paths = models.ManyToManyField(CareerPath, related_name='resources')
    skills = models.ManyToManyField(Skill, related_name='resources', blank=True)
    is_free = models.BooleanField(default=True)
    rating = models.FloatField(default=0.0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title

class FreeTimeActivity(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    suggested_tasks = models.ManyToManyField(PersonalizedTask, blank=True)
    actual_activity = models.TextField(blank=True)
    productivity_score = models.IntegerField(default=0, help_text="Score from 1-10")
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.student.username} - Free Time ({self.start_time.strftime('%Y-%m-%d %H:%M')})"

class AchievementBadge(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    icon = models.CharField(max_length=50)  # Font Awesome icon name
    color = models.CharField(max_length=7, default='#ffd700')  # Hex color code
    criteria = models.JSONField()  # Criteria for earning the badge
    
    def __str__(self):
        return self.name

class StudentAchievement(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    badge = models.ForeignKey(AchievementBadge, on_delete=models.CASCADE)
    earned_date = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['student', 'badge']
    
    def __str__(self):
        return f"{self.student.username} - {self.badge.name}"
