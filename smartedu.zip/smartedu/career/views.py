from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from django.contrib import messages
from .models import *
from attendance.models import UserProfile, ClassSchedule, StudentMark, Attendance
import json
import requests
import openai
from datetime import datetime, timedelta
from django.db.models import Count, Q
from django.conf import settings
import os
import logging

@login_required
def career_dashboard(request):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    if user_profile.user_type != 'student':
        messages.error(request, 'Career guidance is only available for students.')
        return redirect('dashboard')
    
    # Get or create student career profile
    career_profile, created = StudentCareerProfile.objects.get_or_create(student=request.user)
    
    # Get personalized tasks
    pending_tasks = PersonalizedTask.objects.filter(student=request.user, is_completed=False).order_by('-priority', 'due_date')
    completed_tasks = PersonalizedTask.objects.filter(student=request.user, is_completed=True).order_by('-completed_at')[:5]
    
    # Get free time activities
    recent_activities = FreeTimeActivity.objects.filter(student=request.user).order_by('-created_at')[:5]
    
    # Get achievements
    achievements = StudentAchievement.objects.filter(student=request.user).order_by('-earned_date')[:10]
    
    # Get AI career recommendations
    ai_recommendations = get_ai_career_recommendations(request.user)
    
    # Get career paths
    career_paths = CareerPath.objects.filter(is_active=True)
    
    context = {
        'career_profile': career_profile,
        'pending_tasks': pending_tasks,
        'completed_tasks': completed_tasks,
        'recent_activities': recent_activities,
        'achievements': achievements,
        'career_paths': career_paths,
        'ai_recommendations': ai_recommendations,
    }
    
    return render(request, 'career_dashboard.html', context)

@login_required
def career_profile(request):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    if user_profile.user_type != 'student':
        messages.error(request, 'Career profiles are only available for students.')
        return redirect('dashboard')
    
    career_profile, created = StudentCareerProfile.objects.get_or_create(student=request.user)
    
    if request.method == 'POST':
        # Update career profile
        career_goal = request.POST.get('career_goal')
        graduation_year = request.POST.get('graduation_year')
        interested_careers = request.POST.getlist('interested_careers')
        
        career_profile.career_goal = career_goal
        if graduation_year:
            career_profile.graduation_year = int(graduation_year)
        career_profile.save()
        
        # Update interested careers
        career_profile.interested_careers.clear()
        for career_id in interested_careers:
            try:
                career = CareerPath.objects.get(id=career_id)
                career_profile.interested_careers.add(career)
            except CareerPath.DoesNotExist:
                pass
        
        messages.success(request, 'Career profile updated successfully!')
        return redirect('career:profile')
    
    career_paths = CareerPath.objects.filter(is_active=True)
    skills = Skill.objects.all()
    student_skills = StudentSkill.objects.filter(student_profile=career_profile)
    
    context = {
        'career_profile': career_profile,
        'career_paths': career_paths,
        'skills': skills,
        'student_skills': student_skills,
    }
    
    return render(request, 'career_profile.html', context)

@login_required
def task_management(request):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    if user_profile.user_type != 'student':
        messages.error(request, 'Task management is only available for students.')
        return redirect('dashboard')
    
    # Get tasks by status
    pending_tasks = PersonalizedTask.objects.filter(
        student=request.user, 
        is_completed=False
    ).order_by('-priority', 'due_date')
    
    completed_tasks = PersonalizedTask.objects.filter(
        student=request.user, 
        is_completed=True
    ).order_by('-completed_at')
    
    context = {
        'pending_tasks': pending_tasks,
        'completed_tasks': completed_tasks,
    }
    
    return render(request, 'career_tasks.html', context)

@csrf_exempt
@login_required
def complete_task(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        task_id = data.get('task_id')
        
        try:
            task = PersonalizedTask.objects.get(id=task_id, student=request.user)
            task.is_completed = True
            task.completed_at = timezone.now()
            task.save()
            
            # Generate new tasks based on completion
            generate_personalized_tasks(request.user)
            
            return JsonResponse({
                'success': True,
                'message': 'Task completed successfully!'
            })
            
        except PersonalizedTask.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Task not found'})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

# AI Career Guidance Functions
def get_ai_career_recommendations(user):
    """
    Generate AI-powered career recommendations using OpenAI API
    """
    try:
        # Set up OpenAI API key
        openai.api_key = getattr(settings, 'OPENAI_API_KEY', os.environ.get('OPENAI_API_KEY'))
        
        if not openai.api_key:
            # Fallback to demo data if no API key
            return get_demo_career_recommendations(user)
        
        # Collect student data
        student_data = collect_student_data(user)
        
        # Create AI prompt
        prompt = create_career_guidance_prompt(student_data)
        
        # Call OpenAI API
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert career guidance counselor with deep knowledge of job markets, educational requirements, and career trends. Provide personalized career recommendations based on student data."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=1500,
            temperature=0.7
        )
        
        # Parse AI response
        ai_content = response.choices[0].message.content
        recommendations = parse_ai_recommendations(ai_content)
        
        # Enhance with real-time job market data
        enhanced_recommendations = enhance_with_job_market_data(recommendations)
        
        return enhanced_recommendations
        
    except Exception as e:
        logger.error(f"Error generating career recommendations: {e}")
        return get_demo_career_recommendations(student_id)


def test_openai_connection():
    """Test OpenAI API connection."""
    try:
        from openai import OpenAI
        from django.conf import settings
        
        if not settings.OPENAI_API_KEY:
            return False
            
        client = OpenAI(api_key=settings.OPENAI_API_KEY)
        
        # Simple test request
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "user", "content": "Say 'API connection successful'"}
            ],
            max_tokens=10
        )
        
        return "successful" in response.choices[0].message.content.lower()
    except Exception as e:
        logger.error(f"OpenAI API test failed: {e}")
        return False


def test_adzuna_connection():
    """Test Adzuna API connection."""
    try:
        from django.conf import settings
        import requests
        
        if not settings.ADZUNA_APP_ID or not settings.ADZUNA_APP_KEY:
            return False
            
        # Simple test request to get job categories
        url = f"https://api.adzuna.com/v1/api/jobs/gb/categories"
        params = {
            'app_id': settings.ADZUNA_APP_ID,
            'app_key': settings.ADZUNA_APP_KEY
        }
        
        response = requests.get(url, params=params, timeout=10)
        return response.status_code == 200
    except Exception as e:
        logger.error(f"Adzuna API test failed: {e}")
        return False

def collect_student_data(user):
    """
    Collect comprehensive student data for AI analysis
    """
    try:
        # Get user profile
        user_profile = UserProfile.objects.get(user=user)
        
        # Get academic performance
        grades = StudentMark.objects.filter(student=user).select_related('exam__subject')
        
        # Calculate subject averages
        subject_performance = {}
        for grade in grades:
            subject = grade.exam.subject.name
            if subject not in subject_performance:
                subject_performance[subject] = []
            subject_performance[subject].append(grade.get_percentage())
        
        # Average grades by subject
        subject_averages = {}
        for subject, scores in subject_performance.items():
            subject_averages[subject] = sum(scores) / len(scores) if scores else 0
        
        # Get attendance data
        attendance_records = Attendance.objects.filter(student=user)
        total_classes = attendance_records.count()
        attended_classes = attendance_records.filter(status='present').count()
        attendance_rate = (attended_classes / total_classes * 100) if total_classes > 0 else 0
        
        # Get career profile
        career_profile, _ = StudentCareerProfile.objects.get_or_create(student=user)
        
        # Get extracurricular activities
        activities = FreeTimeActivity.objects.filter(student=user, activity_type__isnull=False)
        
        # Get completed tasks and skills
        completed_tasks = PersonalizedTask.objects.filter(student=user, is_completed=True)
        
        return {
            'user_info': {
                'name': user.get_full_name() or user.username,
                'age': getattr(user_profile, 'age', None),
            },
            'academic_performance': subject_averages,
            'overall_gpa': calculate_overall_gpa(grades),
            'attendance_rate': attendance_rate,
            'interests': career_profile.career_goal or "Not specified",
            'graduation_year': career_profile.graduation_year,
            'extracurricular_activities': [activity.actual_activity for activity in activities if activity.actual_activity],
            'completed_tasks_count': completed_tasks.count(),
            'personality_traits': get_personality_insights(user),
            'strengths': identify_student_strengths(subject_averages, activities),
            'areas_for_improvement': identify_improvement_areas(subject_averages)
        }
        
    except Exception as e:
        logging.error(f"Error collecting student data: {str(e)}")
        return {}

def create_career_guidance_prompt(student_data):
    """
    Create a comprehensive prompt for AI career guidance
    """
    prompt = f"""
    Please analyze the following student profile and provide personalized career recommendations:
    
    Student Profile:
    - Name: {student_data.get('user_info', {}).get('name', 'Student')}
    - Overall GPA: {student_data.get('overall_gpa', 'N/A')}
    - Attendance Rate: {student_data.get('attendance_rate', 'N/A')}%
    - Graduation Year: {student_data.get('graduation_year', 'Not specified')}
    - Career Interests: {student_data.get('interests', 'Not specified')}
    
    Academic Performance by Subject:
    {format_subject_performance(student_data.get('academic_performance', {}))}
    
    Strengths: {', '.join(student_data.get('strengths', ['None identified']))}
    Areas for Improvement: {', '.join(student_data.get('areas_for_improvement', ['None identified']))}
    
    Extracurricular Activities: {', '.join(student_data.get('extracurricular_activities', ['None listed']))}
    
    Please provide:
    1. Top 5 career recommendations with reasoning
    2. Required skills for each career
    3. Educational pathways needed
    4. Current job market outlook
    5. Specific action steps for the student
    6. Confidence score (1-100) for each recommendation
    
    Format your response as JSON with the following structure:
    {{
        "recommendations": [
            {{
                "title": "Career Title",
                "category": "Industry Category",
                "description": "Brief description",
                "confidence_score": 85,
                "reasoning": ["reason 1", "reason 2"],
                "required_skills": ["skill 1", "skill 2"],
                "education_path": ["step 1", "step 2"],
                "job_outlook": "Market outlook description",
                "salary_range": "$XX,XXX - $XX,XXX",
                "action_steps": ["action 1", "action 2"]
            }}
        ]
    }}
    """
    
    return prompt

def format_subject_performance(performance):
    """
    Format subject performance for the AI prompt
    """
    if not performance:
        return "No academic data available"
    
    formatted = []
    for subject, average in performance.items():
        formatted.append(f"- {subject}: {average:.1f}%")
    
    return "\n".join(formatted)

def calculate_overall_gpa(grades):
    """
    Calculate overall GPA from grades
    """
    if not grades:
        return 0
    
    total_percentage = sum(grade.get_percentage() for grade in grades)
    average_percentage = total_percentage / len(grades)
    
    # Convert percentage to 4.0 GPA scale
    if average_percentage >= 97:
        return 4.0
    elif average_percentage >= 93:
        return 3.7
    elif average_percentage >= 90:
        return 3.3
    elif average_percentage >= 87:
        return 3.0
    elif average_percentage >= 83:
        return 2.7
    elif average_percentage >= 80:
        return 2.3
    elif average_percentage >= 77:
        return 2.0
    elif average_percentage >= 73:
        return 1.7
    elif average_percentage >= 70:
        return 1.3
    elif average_percentage >= 67:
        return 1.0
    else:
        return 0.7

def get_personality_insights(user):
    """
    Generate personality insights based on user activities and performance
    """
    insights = []
    
    # Analyze based on activities
    activities = FreeTimeActivity.objects.filter(student=user)
    
    if activities.filter(activity_type='study').count() > activities.count() * 0.6:
        insights.append("Academically focused")
    
    if activities.filter(activity_type='sports').exists():
        insights.append("Team player")
    
    if activities.filter(activity_type='creative').exists():
        insights.append("Creative thinker")
    
    # Analyze based on task completion patterns
    tasks = PersonalizedTask.objects.filter(student=user, is_completed=True)
    if tasks.count() > 10:
        insights.append("Goal-oriented")
    
    return insights if insights else ["Developing"]

def identify_student_strengths(subject_averages, activities):
    """
    Identify student strengths based on performance
    """
    strengths = []
    
    # Academic strengths
    for subject, average in subject_averages.items():
        if average >= 85:
            strengths.append(f"Strong in {subject}")
    
    # Activity-based strengths
    activity_types = [activity.activity_type for activity in activities if activity.activity_type]
    if 'leadership' in activity_types:
        strengths.append("Leadership skills")
    if 'creative' in activity_types:
        strengths.append("Creative abilities")
    if 'technical' in activity_types:
        strengths.append("Technical aptitude")
    
    return strengths if strengths else ["Developing strengths"]

def identify_improvement_areas(subject_averages):
    """
    Identify areas where student needs improvement
    """
    improvements = []
    
    for subject, average in subject_averages.items():
        if average < 70:
            improvements.append(f"Improve {subject} performance")
    
    return improvements if improvements else ["Maintain current performance"]

def parse_ai_recommendations(ai_content):
    """
    Parse AI response into structured recommendations
    """
    try:
        # Try to parse JSON response
        import re
        json_match = re.search(r'\{.*\}', ai_content, re.DOTALL)
        if json_match:
            recommendations_data = json.loads(json_match.group())
            return recommendations_data.get('recommendations', [])
    except:
        pass
    
    # Fallback parsing if JSON fails
    return parse_text_recommendations(ai_content)

def parse_text_recommendations(text_content):
    """
    Parse text-based AI response into structured data
    """
    # Basic parsing logic for non-JSON responses
    recommendations = []
    
    # This is a simplified parser - in production you'd want more robust parsing
    lines = text_content.split('\n')
    current_recommendation = {}
    
    for line in lines:
        line = line.strip()
        if 'Career:' in line or 'Recommendation:' in line:
            if current_recommendation:
                recommendations.append(current_recommendation)
            current_recommendation = {
                'title': line.split(':', 1)[1].strip(),
                'category': 'General',
                'description': '',
                'confidence_score': 75,
                'reasoning': [],
                'required_skills': [],
                'education_path': [],
                'job_outlook': 'Positive',
                'salary_range': 'Competitive',
                'action_steps': []
            }
    
    if current_recommendation:
        recommendations.append(current_recommendation)
    
    return recommendations[:5]  # Return top 5

def enhance_with_job_market_data(recommendations):
    """
    Enhance recommendations with real-time job market data
    """
    try:
        # Use a job market API (example with Adzuna API)
        for recommendation in recommendations:
            job_data = fetch_job_market_data(recommendation['title'])
            if job_data:
                recommendation.update({
                    'job_count': job_data.get('count', 0),
                    'average_salary': job_data.get('average_salary', recommendation.get('salary_range')),
                    'top_locations': job_data.get('locations', []),
                    'trending': job_data.get('growth_rate', 0) > 0
                })
    except Exception as e:
        logging.error(f"Error enhancing with job market data: {str(e)}")
    
    return recommendations

def fetch_job_market_data(job_title):
    """
    Fetch real-time job market data from external API
    """
    try:
        # Example using Adzuna API (free tier available)
        # You can also use Indeed API, LinkedIn API, or other job market APIs
        
        app_id = getattr(settings, 'ADZUNA_APP_ID', os.environ.get('ADZUNA_APP_ID'))
        app_key = getattr(settings, 'ADZUNA_APP_KEY', os.environ.get('ADZUNA_APP_KEY'))
        
        if not app_id or not app_key:
            return None
        
        # Adzuna API endpoint for US job search
        url = f"https://api.adzuna.com/v1/api/jobs/us/search/1"
        params = {
            'app_id': app_id,
            'app_key': app_key,
            'what': job_title,
            'results_per_page': 100,
            'content-type': 'application/json'
        }
        
        response = requests.get(url, params=params, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            # Extract useful information
            results = data.get('results', [])
            
            if results:
                salaries = [job.get('salary_max', 0) for job in results if job.get('salary_max')]
                locations = [job.get('location', {}).get('display_name', '') for job in results]
                
                return {
                    'count': data.get('count', 0),
                    'average_salary': f"${int(sum(salaries) / len(salaries)):,}" if salaries else None,
                    'locations': list(set(locations))[:5],  # Top 5 unique locations
                    'growth_rate': 5  # Default growth rate
                }
        
    except Exception as e:
        logging.error(f"Error fetching job market data: {str(e)}")
    
    return None

def get_demo_career_recommendations(user):
    """
    Provide demo recommendations when AI API is not available
    """
    return [
        {
            'title': 'Software Engineer',
            'category': 'Technology',
            'description': 'Design and develop software applications',
            'confidence_score': 85,
            'reasoning': ['Strong analytical skills', 'High demand in market'],
            'required_skills': ['Programming', 'Problem solving', 'Teamwork'],
            'education_path': ['Bachelor in Computer Science', 'Coding bootcamp'],
            'job_outlook': 'Excellent - 22% growth expected',
            'salary_range': '$70,000 - $150,000',
            'action_steps': ['Learn programming languages', 'Build portfolio projects']
        },
        {
            'title': 'Data Scientist',
            'category': 'Technology',
            'description': 'Analyze data to help organizations make decisions',
            'confidence_score': 78,
            'reasoning': ['Strong math skills', 'Growing field'],
            'required_skills': ['Statistics', 'Programming', 'Data visualization'],
            'education_path': ['Statistics/Math degree', 'Data science certification'],
            'job_outlook': 'Excellent - 31% growth expected',
            'salary_range': '$85,000 - $170,000',
            'action_steps': ['Learn Python/R', 'Work with datasets']
        }
    ]

@login_required
def free_time_tracker(request):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    
    if user_profile.user_type != 'student':
        messages.error(request, 'Free time tracking is only available for students.')
        return redirect('dashboard')
    
    # Get today's schedule
    today = timezone.now().date()
    today_schedule = ClassSchedule.objects.filter(
        subject__students=request.user,
        day_of_week=today.strftime('%A').lower(),
        is_active=True
    ).order_by('start_time')
    
    # Calculate break times between classes
    break_times = []
    schedule_list = list(today_schedule)
    
    if schedule_list:
        # Before first class
        first_class = schedule_list[0]
        if first_class.start_time.hour > 8:  # Assume day starts at 8 AM
            from datetime import time
            break_times.append({
                'start_time': time(8, 0),
                'end_time': first_class.start_time,
                'duration_minutes': (first_class.start_time.hour - 8) * 60 + first_class.start_time.minute,
                'type': 'before_classes'
            })
        
        # Between classes
        for i in range(len(schedule_list) - 1):
            current_class = schedule_list[i]
            next_class = schedule_list[i + 1]
            
            # Calculate gap between classes
            gap_start = current_class.end_time
            gap_end = next_class.start_time
            
            # Convert to minutes for easier calculation
            gap_minutes = (gap_end.hour * 60 + gap_end.minute) - (gap_start.hour * 60 + gap_start.minute)
            
            if gap_minutes > 15:  # Only show breaks longer than 15 minutes
                break_times.append({
                    'start_time': gap_start,
                    'end_time': gap_end,
                    'duration_minutes': gap_minutes,
                    'type': 'between_classes'
                })
        
        # After last class
        last_class = schedule_list[-1]
        if last_class.end_time.hour < 18:  # Assume day ends at 6 PM
            from datetime import time
            end_minutes = (18 * 60) - (last_class.end_time.hour * 60 + last_class.end_time.minute)
            break_times.append({
                'start_time': last_class.end_time,
                'end_time': time(18, 0),
                'duration_minutes': end_minutes,
                'type': 'after_classes'
            })
    
    # Get free time activities
    recent_activities = FreeTimeActivity.objects.filter(
        student=request.user
    ).order_by('-created_at')[:10]
    
    # Get available tasks for free time, categorized by duration
    short_tasks = PersonalizedTask.objects.filter(
        student=request.user,
        is_completed=False,
        estimated_duration__lte=30
    ).order_by('-priority')[:5]
    
    medium_tasks = PersonalizedTask.objects.filter(
        student=request.user,
        is_completed=False,
        estimated_duration__gt=30,
        estimated_duration__lte=60
    ).order_by('-priority')[:5]
    
    long_tasks = PersonalizedTask.objects.filter(
        student=request.user,
        is_completed=False,
        estimated_duration__gt=60
    ).order_by('-priority')[:3]
    
    context = {
        'today_schedule': today_schedule,
        'break_times': break_times,
        'recent_activities': recent_activities,
        'short_tasks': short_tasks,
        'medium_tasks': medium_tasks,
        'long_tasks': long_tasks,
        'today': today,
    }
    
    return render(request, 'free_time.html', context)

@csrf_exempt
@login_required
def log_free_time_activity(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        start_time = data.get('start_time')
        end_time = data.get('end_time')
        activity = data.get('activity')
        productivity_score = data.get('productivity_score', 5)
        task_ids = data.get('task_ids', [])
        
        try:
            # Parse datetime strings
            start_dt = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
            end_dt = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
            
            # Create free time activity
            free_time = FreeTimeActivity.objects.create(
                student=request.user,
                start_time=start_dt,
                end_time=end_dt,
                actual_activity=activity,
                productivity_score=productivity_score
            )
            
            # Add suggested tasks
            for task_id in task_ids:
                try:
                    task = PersonalizedTask.objects.get(id=task_id, student=request.user)
                    free_time.suggested_tasks.add(task)
                except PersonalizedTask.DoesNotExist:
                    pass
            
            return JsonResponse({
                'success': True,
                'message': 'Free time activity logged successfully!'
            })
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@csrf_exempt
@login_required
def add_skill(request):
    """Add a skill to student's profile"""
    if request.method == 'POST':
        skill_id = request.POST.get('skill_id')
        proficiency_level = request.POST.get('proficiency_level')
        
        try:
            # Get or create student career profile
            career_profile, created = StudentCareerProfile.objects.get_or_create(student=request.user)
            
            # Get the skill
            skill = Skill.objects.get(id=skill_id)
            
            # Create or update student skill
            student_skill, created = StudentSkill.objects.get_or_create(
                student_profile=career_profile,
                skill=skill,
                defaults={'proficiency_level': int(proficiency_level)}
            )
            
            if not created:
                student_skill.proficiency_level = int(proficiency_level)
                student_skill.save()
            
            return JsonResponse({
                'success': True,
                'message': f'Skill "{skill.name}" added successfully!'
            })
            
        except Skill.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Skill not found'})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

def get_ai_career_recommendations(student):
    """AI-powered career recommendations based on student data"""
    from attendance.models import StudentMark, Subject
    from django.db.models import Avg, Count
    
    try:
        career_profile = StudentCareerProfile.objects.get(student=student)
        
        # Analyze academic performance
        marks = StudentMark.objects.filter(student=student)
        if marks.exists():
            avg_performance = marks.aggregate(avg=Avg('marks_obtained'))['avg'] or 0
            performance_by_subject = marks.values(
                'exam__subject__name'
            ).annotate(
                avg_marks=Avg('marks_obtained'),
                count=Count('id')
            )
        else:
            avg_performance = 0
            performance_by_subject = []
        
        # Get current skills
        current_skills = career_profile.current_skills.all()
        skill_names = [skill.name.lower() for skill in current_skills]
        
        # AI recommendation logic
        recommendations = []
        
        # Performance-based recommendations
        if avg_performance >= 80:
            recommendations.append({
                'type': 'career_path',
                'title': 'Consider Advanced Specialization',
                'description': 'Your excellent academic performance suggests you could pursue advanced specialization or research roles.',
                'confidence': 0.9,
                'icon': 'fas fa-graduation-cap',
                'color': 'success'
            })
        
        # Skill-based recommendations
        if any('programming' in skill or 'python' in skill or 'javascript' in skill for skill in skill_names):
            recommendations.append({
                'type': 'career_path',
                'title': 'Software Development Track',
                'description': 'Your programming skills make you an ideal candidate for software development roles.',
                'confidence': 0.85,
                'icon': 'fas fa-code',
                'color': 'primary'
            })
        
        if any('data' in skill or 'statistics' in skill or 'analytics' in skill for skill in skill_names):
            recommendations.append({
                'type': 'career_path',
                'title': 'Data Science Opportunity',
                'description': 'Your analytical skills align perfectly with data science career paths.',
                'confidence': 0.8,
                'icon': 'fas fa-chart-line',
                'color': 'info'
            })
        
        # Subject performance analysis
        for subject_data in performance_by_subject:
            if subject_data['avg_marks'] >= 85:
                subject_name = subject_data['exam__subject__name'].lower()
                if 'computer' in subject_name or 'programming' in subject_name:
                    recommendations.append({
                        'type': 'skill_development',
                        'title': 'Advanced Computing Skills',
                        'description': f'Excel in {subject_data["exam__subject__name"]} suggests potential in advanced computing fields.',
                        'confidence': 0.75,
                        'icon': 'fas fa-laptop-code',
                        'color': 'warning'
                    })
        
        # Market trend recommendations (simulated)
        market_trends = [
            {
                'type': 'market_trend',
                'title': 'AI & Machine Learning Boom',
                'description': 'AI/ML roles are growing 40% annually. Consider building skills in this area.',
                'confidence': 0.95,
                'icon': 'fas fa-robot',
                'color': 'danger'
            },
            {
                'type': 'market_trend',
                'title': 'Remote Work Opportunities',
                'description': 'Tech roles offer 60% more remote opportunities. Build digital collaboration skills.',
                'confidence': 0.8,
                'icon': 'fas fa-home',
                'color': 'secondary'
            }
        ]
        
        # Add market trends if student has relevant interests
        if career_profile.interested_careers.filter(name__icontains='Software').exists():
            recommendations.extend(market_trends)
        
        # Skill gap analysis
        interested_careers = career_profile.interested_careers.all()
        for career in interested_careers:
            required_skills = career.required_skills.all()
            missing_skills = required_skills.exclude(
                id__in=current_skills.values_list('id', flat=True)
            )
            
            if missing_skills.exists():
                skill_names = ', '.join([skill.name for skill in missing_skills[:3]])
                recommendations.append({
                    'type': 'skill_gap',
                    'title': f'Skill Gap in {career.name}',
                    'description': f'Consider developing: {skill_names}',
                    'confidence': 0.7,
                    'icon': 'fas fa-exclamation-triangle',
                    'color': 'warning'
                })
        
        return sorted(recommendations, key=lambda x: x['confidence'], reverse=True)
        
    except StudentCareerProfile.DoesNotExist:
        return []

def generate_personalized_tasks(student):
    """Generate personalized tasks based on student's profile and performance"""
    try:
        career_profile = StudentCareerProfile.objects.get(student=student)
        
        # Get AI recommendations for task generation
        ai_recommendations = get_ai_career_recommendations(student)
        
        # Generate tasks based on AI recommendations
        tasks_to_create = []
        
        # High-confidence recommendations get priority tasks
        for rec in ai_recommendations[:2]:
            if rec['confidence'] > 0.8:
                if rec['type'] == 'career_path':
                    tasks_to_create.append({
                        'title': f'Research {rec["title"]}',
                        'description': rec['description'] + ' Research specific roles and requirements.',
                        'task_type': 'career_exploration',
                        'priority': 'high',
                        'estimated_duration': 45,
                    })
                elif rec['type'] == 'skill_gap':
                    tasks_to_create.append({
                        'title': 'Skill Development Plan',
                        'description': rec['description'] + ' Create a learning plan for missing skills.',
                        'task_type': 'skill_building',
                        'priority': 'medium',
                        'estimated_duration': 60,
                    })
        
        # Add some standard tasks
        tasks_to_create.extend([
            {
                'title': 'Daily Learning Goal',
                'description': 'Set and achieve a small learning goal for today.',
                'task_type': 'skill_building',
                'priority': 'medium',
                'estimated_duration': 30,
            },
            {
                'title': 'Review Class Notes',
                'description': 'Go through today\'s class materials and make summary notes.',
                'task_type': 'study',
                'priority': 'high',
                'estimated_duration': 25,
            }
        ])
        
        for task_data in tasks_to_create:
            # Check if similar task already exists
            existing_task = PersonalizedTask.objects.filter(
                student=student,
                title=task_data['title'],
                is_completed=False
            ).exists()
            
            if not existing_task:
                PersonalizedTask.objects.create(
                    student=student,
                    **task_data
                )
                
    except StudentCareerProfile.DoesNotExist:
        pass  # Profile doesn't exist yet
