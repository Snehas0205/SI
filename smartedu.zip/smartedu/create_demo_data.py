#!/usr/bin/env python
"""
Demo Data Creation Script for SmartTrack
Creates sample users, subjects, attendance sessions, and career data
"""
import os
import django
import sys
from datetime import datetime, timedelta

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smarttrack.settings')
django.setup()

from django.contrib.auth.models import User
from attendance.models import (
    UserProfile, Subject, ClassSchedule, AttendanceSession, Attendance, AttendanceGoal,
    Exam, StudentMark, ExtracurricularActivity, StudentActivity
)
from career.models import CareerPath, Skill, StudentCareerProfile, PersonalizedTask, CareerResource, AchievementBadge

def create_demo_data():
    print("Creating demo data for SmartTrack...")
    
    # Create demo users if they don't exist
    if not User.objects.filter(username='student').exists():
        student_user = User.objects.create_user(
            username='student',
            password='password123',
            first_name='John',
            last_name='Doe',
            email='student@example.com'
        )
        UserProfile.objects.create(
            user=student_user,
            user_type='student',
            student_id='STU001',
            phone='+1234567890'
        )
        print("✓ Created student user")
    
    if not User.objects.filter(username='teacher').exists():
        teacher_user = User.objects.create_user(
            username='teacher',
            password='password123',
            first_name='Jane',
            last_name='Smith',
            email='teacher@example.com'
        )
        UserProfile.objects.create(
            user=teacher_user,
            user_type='teacher',
            phone='+1234567891'
        )
        print("✓ Created teacher user")
    
    # Create Career Paths
    if CareerPath.objects.count() < 5:
        career_paths = [
            {'name': 'Software Development', 'description': 'Build applications and systems', 'icon': 'code', 'color': '#007bff'},
            {'name': 'Data Science', 'description': 'Analyze data and build predictive models', 'icon': 'chart-bar', 'color': '#28a745'},
            {'name': 'Cybersecurity', 'description': 'Protect digital assets and infrastructure', 'icon': 'shield-alt', 'color': '#dc3545'},
            {'name': 'UI/UX Design', 'description': 'Design user interfaces and experiences', 'icon': 'paint-brush', 'color': '#ffc107'},
            {'name': 'Machine Learning', 'description': 'Develop AI and ML solutions', 'icon': 'robot', 'color': '#6f42c1'},
        ]
        
        for cp_data in career_paths:
            CareerPath.objects.get_or_create(**cp_data)
        print("✓ Created career paths")
    
    # Create Skills
    if Skill.objects.count() < 10:
        skills = [
            {'name': 'Python Programming', 'category': 'technical'},
            {'name': 'JavaScript', 'category': 'technical'},
            {'name': 'Database Design', 'category': 'technical'},
            {'name': 'Problem Solving', 'category': 'soft'},
            {'name': 'Communication', 'category': 'soft'},
            {'name': 'Mathematics', 'category': 'academic'},
            {'name': 'Statistics', 'category': 'academic'},
            {'name': 'Graphic Design', 'category': 'creative'},
            {'name': 'Web Development', 'category': 'technical'},
            {'name': 'Project Management', 'category': 'soft'},
        ]
        
        for skill_data in skills:
            skill, created = Skill.objects.get_or_create(**skill_data)
            if created:
                # Add skills to relevant career paths
                if 'Programming' in skill.name or 'Development' in skill.name:
                    career_paths = CareerPath.objects.filter(name__in=['Software Development', 'Machine Learning'])
                    skill.career_paths.set(career_paths)
                elif skill.name in ['Statistics', 'Mathematics']:
                    career_paths = CareerPath.objects.filter(name__in=['Data Science', 'Machine Learning'])
                    skill.career_paths.set(career_paths)
        print("✓ Created skills")
    
    # Create Subjects for teacher
    teacher = User.objects.filter(userprofile__user_type='teacher').first()
    student = User.objects.filter(userprofile__user_type='student').first()
    
    if teacher and Subject.objects.count() < 5:
        subjects = [
            {'name': 'Computer Science Fundamentals', 'code': 'CS101'},
            {'name': 'Database Systems', 'code': 'CS201'},
            {'name': 'Web Development', 'code': 'CS301'},
            {'name': 'Data Structures', 'code': 'CS102'},
        ]
        
        for sub_data in subjects:
            subject, created = Subject.objects.get_or_create(
                code=sub_data['code'],
                defaults={'name': sub_data['name'], 'teacher': teacher}
            )
            if student:
                subject.students.add(student)
        print("✓ Created subjects")
    
    # Create Class Schedules
    if ClassSchedule.objects.count() < 5:
        schedules = [
            {'day_of_week': 'monday', 'start_time': '09:00', 'end_time': '10:30', 'room_number': 'A101'},
            {'day_of_week': 'wednesday', 'start_time': '11:00', 'end_time': '12:30', 'room_number': 'B201'},
            {'day_of_week': 'friday', 'start_time': '14:00', 'end_time': '15:30', 'room_number': 'C301'},
        ]
        
        subjects = Subject.objects.all()[:3]
        for i, schedule_data in enumerate(schedules):
            if i < len(subjects):
                ClassSchedule.objects.get_or_create(
                    subject=subjects[i],
                    **schedule_data
                )
        print("✓ Created class schedules")
    
    # Create Career Profile for student
    if student and not StudentCareerProfile.objects.filter(student=student).exists():
        career_profile = StudentCareerProfile.objects.create(
            student=student,
            career_goal="Become a full-stack software developer",
            graduation_year=2025
        )
        # Add interested careers
        software_dev = CareerPath.objects.filter(name='Software Development').first()
        if software_dev:
            career_profile.interested_careers.add(software_dev)
        print("✓ Created student career profile")
    
    # Create Personalized Tasks
    if student and PersonalizedTask.objects.filter(student=student).count() < 5:
        tasks = [
            {
                'title': 'Complete Python Tutorial',
                'description': 'Finish the online Python programming course',
                'task_type': 'skill_building',
                'priority': 'high',
                'estimated_duration': 60,
            },
            {
                'title': 'Review Database Concepts',
                'description': 'Go through SQL and database design principles',
                'task_type': 'study',
                'priority': 'medium',
                'estimated_duration': 45,
            },
            {
                'title': 'Research Tech Companies',
                'description': 'Look into potential internship opportunities',
                'task_type': 'career_exploration',
                'priority': 'low',
                'estimated_duration': 30,
            },
        ]
        
        for task_data in tasks:
            PersonalizedTask.objects.create(student=student, **task_data)
        print("✓ Created personalized tasks")
    
    # Create Achievement Badges
    if AchievementBadge.objects.count() < 3:
        badges = [
            {
                'name': 'Perfect Attendance',
                'description': 'Achieved 100% attendance for a month',
                'icon': 'star',
                'color': '#ffd700',
                'criteria': {'attendance_percentage': 100, 'period': 'month'}
            },
            {
                'name': 'Task Master',
                'description': 'Completed 50 personalized tasks',
                'icon': 'trophy',
                'color': '#ff6b35',
                'criteria': {'completed_tasks': 50}
            },
            {
                'name': 'Early Bird',
                'description': 'Never late to any class for a week',
                'icon': 'clock',
                'color': '#4ecdc4',
                'criteria': {'no_late_marks': 7}
            },
        ]
        
        for badge_data in badges:
            AchievementBadge.objects.get_or_create(**badge_data)
        print("✓ Created achievement badges")
    
    # Create sample exams and marks
    if teacher and student and Exam.objects.count() < 5:
        subjects = Subject.objects.all()[:2]
        for subject in subjects:
            # Create some exams
            exam1 = Exam.objects.create(
                subject=subject,
                name=f"{subject.code} Quiz 1",
                exam_type='quiz',
                total_marks=20,
                date=datetime.now().date(),
                created_by=teacher
            )
            
            exam2 = Exam.objects.create(
                subject=subject,
                name=f"{subject.code} Midterm",
                exam_type='midterm',
                total_marks=100,
                date=datetime.now().date(),
                created_by=teacher
            )
            
            # Create marks for student
            StudentMark.objects.create(
                student=student,
                exam=exam1,
                marks_obtained=18,
                graded_by=teacher
            )
            
            StudentMark.objects.create(
                student=student,
                exam=exam2,
                marks_obtained=85,
                graded_by=teacher
            )
        
        print("✓ Created sample exams and marks")
    
    # Create extracurricular activities
    if ExtracurricularActivity.objects.count() < 5:
        activities = [
            {
                'name': 'Annual Tech Fest',
                'activity_type': 'competition',
                'description': 'Technical competition featuring programming, robotics, and innovation challenges.',
                'date_start': datetime.now().date() + timedelta(days=30),
                'location': 'Main Campus',
                'organizer': 'Computer Science Department',
                'max_participants': 50
            },
            {
                'name': 'Community Service Drive',
                'activity_type': 'volunteer',
                'description': 'Help local communities with educational and environmental initiatives.',
                'date_start': datetime.now().date() + timedelta(days=15),
                'date_end': datetime.now().date() + timedelta(days=45),
                'location': 'Various Locations',
                'organizer': 'Student Council'
            },
            {
                'name': 'Inter-College Basketball',
                'activity_type': 'sports',
                'description': 'Basketball tournament between colleges.',
                'date_start': datetime.now().date() + timedelta(days=20),
                'location': 'Sports Complex',
                'max_participants': 12
            },
            {
                'name': 'Cultural Night',
                'activity_type': 'cultural',
                'description': 'Showcase of music, dance, and artistic talents.',
                'date_start': datetime.now().date() + timedelta(days=60),
                'location': 'Auditorium',
                'organizer': 'Cultural Committee'
            }
        ]
        
        for activity_data in activities:
            ExtracurricularActivity.objects.create(**activity_data)
        
        # Register student for one activity
        if student:
            activity = ExtracurricularActivity.objects.first()
            if activity:
                StudentActivity.objects.create(
                    student=student,
                    activity=activity,
                    status='registered'
                )
        
        print("✓ Created extracurricular activities")
    
    print("\n🎉 Demo data creation completed!")
    print("You can now login with:")
    print("  Student: student / password123")
    print("  Teacher: teacher / password123")
    print("  Admin: admin / (your admin password)")
    print("\n🚀 New Features Added:")
    print("  ✅ QR Code Attendance Scanner")
    print("  ✅ AI-Powered Career Recommendations")
    print("  ✅ Smart Free Time Tracker with Break Detection")
    print("  ✅ Comprehensive Marks & Grades System")
    print("  ✅ Extracurricular Activities Management")

if __name__ == '__main__':
    create_demo_data()