// Login Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const submitButton = document.querySelector('button[type="submit"]');

    // Form validation
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const username = usernameInput.value.trim();
            const password = passwordInput.value.trim();

            if (!username) {
                e.preventDefault();
                showFieldError(usernameInput, 'Username is required');
                return;
            }

            if (!password) {
                e.preventDefault();
                showFieldError(passwordInput, 'Password is required');
                return;
            }

            // Show loading state
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Signing in...';
            }
        });

        // Clear error states on input
        [usernameInput, passwordInput].forEach(input => {
            if (input) {
                input.addEventListener('input', function() {
                    clearFieldError(this);
                });
            }
        });
    }

    // Auto-focus username field
    if (usernameInput) {
        usernameInput.focus();
    }

    console.log('Login page loaded successfully!');
});

function showFieldError(field, message) {
    // Remove existing error
    clearFieldError(field);
    
    // Add error class
    field.classList.add('is-invalid');
    
    // Create error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'invalid-feedback';
    errorDiv.textContent = message;
    
    // Insert error message
    field.parentNode.appendChild(errorDiv);
}

function clearFieldError(field) {
    field.classList.remove('is-invalid');
    const errorMsg = field.parentNode.querySelector('.invalid-feedback');
    if (errorMsg) {
        errorMsg.remove();
    }
}