// AI Session Chat JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initChatInterface();
    initSuggestionButtons();
    scrollToBottom();
});

function initChatInterface() {
    const form = document.getElementById('message-form');
    const textarea = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    
    if (!form || !textarea || !sendButton) return;
    
    // Auto-resize textarea
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
        
        // Enable/disable send button
        if (this.value.trim()) {
            sendButton.disabled = false;
            sendButton.classList.remove('disabled');
        } else {
            sendButton.disabled = true;
            sendButton.classList.add('disabled');
        }
    });
    
    // Handle form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        sendMessage();
    });
    
    // Handle Enter key (Shift+Enter for new line)
    textarea.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (this.value.trim()) {
                sendMessage();
            }
        }
    });
    
    // Focus on textarea
    textarea.focus();
}

function sendMessage() {
    const textarea = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const message = textarea.value.trim();
    
    if (!message || sendButton.disabled) return;
    
    // Disable form
    textarea.disabled = true;
    sendButton.disabled = true;
    
    // Show loading state
    const originalButtonContent = sendButton.innerHTML;
    sendButton.innerHTML = '<i class=\"fas fa-spinner fa-spin\"></i>';
    
    // Add user message to chat immediately
    addMessageToChat('user', message);
    
    // Clear input
    textarea.value = '';
    textarea.style.height = 'auto';
    
    // Scroll to bottom
    scrollToBottom();
    
    // Show AI typing indicator
    showTypingIndicator();
    
    // Send AJAX request
    fetch(SEND_MESSAGE_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': CSRF_TOKEN
        },
        body: JSON.stringify({
            message: message
        })
    })
    .then(response => response.json())
    .then(data => {
        hideTypingIndicator();
        
        if (data.success) {
            // Add AI response to chat
            addMessageToChat('ai', data.ai_response);
        } else {
            showError(data.error || 'Failed to get AI response');
        }
    })
    .catch(error => {
        hideTypingIndicator();
        console.error('Error:', error);
        showError('Network error. Please check your connection and try again.');
    })
    .finally(() => {
        // Re-enable form
        textarea.disabled = false;
        sendButton.disabled = false;
        sendButton.innerHTML = originalButtonContent;
        textarea.focus();
        scrollToBottom();
    });
}

function addMessageToChat(type, content) {
    const messagesList = document.getElementById('messages-list');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    
    const now = new Date();
    const timestamp = now.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
    
    const avatar = type === 'user' ? 
        '<i class="fas fa-user"></i>' : 
        '<i class="fas fa-robot"></i>';
    
    const sender = type === 'user' ? 'You' : 'AI Assistant';
    
    messageDiv.innerHTML = `
        <div class="message-avatar">
            ${avatar}
        </div>
        <div class="message-content">
            <div class="message-header">
                <span class="message-sender">${sender}</span>
                <span class="message-timestamp">${timestamp}</span>
            </div>
            <div class="message-text">${formatMessageContent(content)}</div>
        </div>
    `;
    
    messagesList.appendChild(messageDiv);
    
    // Animate message appearance
    requestAnimationFrame(() => {
        messageDiv.style.opacity = '0';
        messageDiv.style.transform = 'translateY(20px)';
        messageDiv.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        
        requestAnimationFrame(() => {
            messageDiv.style.opacity = '1';
            messageDiv.style.transform = 'translateY(0)';
        });
    });
    
    scrollToBottom();
}

function formatMessageContent(content) {
    // Convert line breaks to HTML
    return content.replace(/\n/g, '<br>');
}

function showTypingIndicator() {
    const loadingMessage = document.getElementById('loading-message');
    if (loadingMessage) {
        loadingMessage.style.display = 'flex';
        scrollToBottom();
    }
}

function hideTypingIndicator() {
    const loadingMessage = document.getElementById('loading-message');
    if (loadingMessage) {
        loadingMessage.style.display = 'none';
    }
}

function scrollToBottom() {
    const messagesContainer = document.querySelector('.messages-container');
    if (messagesContainer) {
        setTimeout(() => {
            messagesContainer.scrollTo({
                top: messagesContainer.scrollHeight,
                behavior: 'smooth'
            });
        }, 100);
    }
}

function initSuggestionButtons() {
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('suggestion-btn')) {
            const suggestion = e.target.getAttribute('data-suggestion');
            const textarea = document.getElementById('message-input');
            
            if (textarea && suggestion) {
                textarea.value = suggestion;
                textarea.dispatchEvent(new Event('input'));
                textarea.focus();
                
                // Optionally auto-send suggestion
                // sendMessage();
            }
        }
    });
}

function showError(message) {
    // Create error alert
    const alert = document.createElement('div');
    alert.className = 'alert alert-danger alert-dismissible';
    alert.innerHTML = `
        <i class="fas fa-exclamation-triangle"></i>
        <strong>Error:</strong> ${message}
        <button type="button" class="btn-close" onclick="this.parentElement.remove()">
            <span>&times;</span>
        </button>
    `;
    
    // Insert before messages container
    const sessionContent = document.querySelector('.session-content');
    if (sessionContent) {
        sessionContent.insertBefore(alert, sessionContent.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (alert.parentElement) {
                alert.remove();
            }
        }, 5000);
    }
}

// Add some enhancements
function enhanceChat() {
    // Add message timestamps on hover
    document.addEventListener('mouseover', function(e) {
        if (e.target.closest('.message')) {
            const timestamp = e.target.closest('.message').querySelector('.message-timestamp');
            if (timestamp) {
                timestamp.style.opacity = '1';
            }
        }
    });
    
    document.addEventListener('mouseout', function(e) {
        if (e.target.closest('.message')) {
            const timestamp = e.target.closest('.message').querySelector('.message-timestamp');
            if (timestamp) {
                timestamp.style.opacity = '0.7';
            }
        }
    });
    
    // Add copy message functionality
    document.addEventListener('dblclick', function(e) {
        const messageText = e.target.closest('.message-text');
        if (messageText) {
            const text = messageText.textContent;
            navigator.clipboard.writeText(text).then(() => {
                showTemporaryTooltip(messageText, 'Copied!');
            }).catch(() => {
                console.log('Copy failed');
            });
        }
    });
}

function showTemporaryTooltip(element, text) {
    const tooltip = document.createElement('div');
    tooltip.className = 'temporary-tooltip';
    tooltip.textContent = text;
    
    document.body.appendChild(tooltip);
    
    const rect = element.getBoundingClientRect();
    tooltip.style.left = rect.left + rect.width / 2 - tooltip.offsetWidth / 2 + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
    
    setTimeout(() => {
        tooltip.remove();
    }, 2000);
}

// Initialize enhancements
document.addEventListener('DOMContentLoaded', enhanceChat);

// Add CSS for enhancements
const style = document.createElement('style');
style.textContent = `
    .alert-dismissible {
        position: relative;
        animation: slideDown 0.3s ease-out;
    }
    
    .btn-close {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        font-size: 1.2rem;
        cursor: pointer;
        opacity: 0.7;
        color: inherit;
    }
    
    .btn-close:hover {
        opacity: 1;
    }
    
    .temporary-tooltip {
        position: absolute;
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 0.8rem;
        z-index: 1000;
        animation: fadeInOut 2s ease-in-out;
    }
    
    @keyframes fadeInOut {
        0% { opacity: 0; transform: translateY(10px); }
        20% { opacity: 1; transform: translateY(0); }
        80% { opacity: 1; transform: translateY(0); }
        100% { opacity: 0; transform: translateY(-10px); }
    }
    
    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .message-text {
        cursor: pointer;
    }
    
    .message-text:hover {
        background: rgba(0, 0, 0, 0.02);
        border-radius: 4px;
    }
    
    .message-user .message-text:hover {
        background: rgba(255, 255, 255, 0.1);
    }
`;
document.head.appendChild(style);
