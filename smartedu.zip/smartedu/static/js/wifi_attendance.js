// WiFi Proximity Attendance System
class WiFiAttendance {
    constructor() {
        this.isScanning = false;
        this.currentSession = null;
        this.attendanceMarked = false;
        this.checkInterval = null;
        this.init();
    }

    init() {
        this.checkWiFiSupport();
        this.setupUI();
        this.bindEvents();
    }

    checkWiFiSupport() {
        if (!navigator.geolocation) {
            console.warn('Geolocation is not supported by this browser.');
            return false;
        }

        // Check for WiFi scanning capabilities (limited in browsers for security)
        if ('connection' in navigator) {
            this.connection = navigator.connection;
        }

        return true;
    }

    setupUI() {
        // Create WiFi attendance UI elements
        const wifiUI = document.createElement('div');
        wifiUI.id = 'wifi-attendance-panel';
        wifiUI.innerHTML = `
            <div class="wifi-panel">
                <div class="wifi-header">
                    <i class="fas fa-wifi"></i>
                    <h3>WiFi Proximity Attendance</h3>
                </div>
                <div class="wifi-status" id="wifi-status">
                    <div class="status-indicator" id="status-indicator">
                        <div class="pulse-dot"></div>
                    </div>
                    <span id="status-text">Searching for classroom WiFi...</span>
                </div>
                <div class="wifi-info" id="wifi-info" style="display: none;">
                    <div class="network-info">
                        <strong>Network:</strong> <span id="network-name">--</span>
                    </div>
                    <div class="signal-strength">
                        <strong>Signal:</strong> 
                        <div class="signal-bars" id="signal-bars">
                            <div class="bar"></div>
                            <div class="bar"></div>
                            <div class="bar"></div>
                            <div class="bar"></div>
                        </div>
                    </div>
                    <div class="distance-estimate">
                        <strong>Estimated Distance:</strong> <span id="distance">--</span>m
                    </div>
                </div>
                <div class="wifi-actions" id="wifi-actions">
                    <button class="btn btn-primary" id="start-wifi-scan" onclick="wifiAttendance.startScanning()">
                        <i class="fas fa-search"></i> Start Scanning
                    </button>
                    <button class="btn btn-success" id="mark-attendance" style="display: none;" onclick="wifiAttendance.markAttendance()">
                        <i class="fas fa-check"></i> Mark Attendance
                    </button>
                </div>
                <div class="wifi-log" id="wifi-log">
                    <div class="log-header">Activity Log</div>
                    <div class="log-content" id="log-content"></div>
                </div>
            </div>
        `;

        // Insert after existing QR scanner or create new section
        const dashboard = document.querySelector('.dashboard') || document.querySelector('.container');
        if (dashboard) {
            dashboard.appendChild(wifiUI);
        }
    }

    bindEvents() {
        // Listen for WiFi changes
        if (this.connection) {
            this.connection.addEventListener('change', () => {
                this.onConnectionChange();
            });
        }

        // Auto-start scanning if session is active
        this.checkActiveSession();
    }

    async checkActiveSession() {
        try {
            const response = await fetch('/attendance/wifi-active-session/', {
                method: 'GET',
                headers: {
                    'X-CSRFToken': this.getCSRFToken()
                }
            });
            
            const data = await response.json();
            if (data.active_session) {
                this.currentSession = data.session;
                this.log(`Found active WiFi session: ${data.session.subject_name}`);
                this.updateStatus('Session found', 'found');
                document.getElementById('start-wifi-scan').style.display = 'none';
                this.startAutomaticScanning();
            }
        } catch (error) {
            this.log(`Error checking session: ${error.message}`, 'error');
        }
    }

    startScanning() {
        if (this.isScanning) return;
        
        this.isScanning = true;
        this.updateStatus('Scanning for networks...', 'scanning');
        this.log('Started WiFi proximity scanning');
        
        // Simulate WiFi scanning (real implementation would use WebRTC or native APIs)
        this.simulateWiFiScan();
        
        // Start periodic checks
        this.checkInterval = setInterval(() => {
            this.performProximityCheck();
        }, 3000);
    }

    stopScanning() {
        this.isScanning = false;
        if (this.checkInterval) {
            clearInterval(this.checkInterval);
            this.checkInterval = null;
        }
        this.updateStatus('Scanning stopped', 'stopped');
        this.log('Stopped WiFi proximity scanning');
    }

    startAutomaticScanning() {
        if (!this.currentSession) return;
        
        this.log('Starting automatic proximity detection...');
        this.startScanning();
    }

    simulateWiFiScan() {
        // Simulate finding classroom WiFi
        setTimeout(() => {
            const classroomNetworks = [
                'SmartEdu-Room101',
                'SmartEdu-Lab-A',
                'SmartEdu-Lecture-Hall',
                'Campus-WiFi-Secure'
            ];
            
            const detectedNetwork = classroomNetworks[Math.floor(Math.random() * classroomNetworks.length)];
            const signalStrength = Math.floor(Math.random() * 100) + 1;
            const distance = this.calculateDistance(signalStrength);
            
            this.onNetworkDetected(detectedNetwork, signalStrength, distance);
        }, 2000);
    }

    onNetworkDetected(networkName, signalStrength, distance) {
        document.getElementById('network-name').textContent = networkName;
        document.getElementById('distance').textContent = distance.toFixed(1);
        document.getElementById('wifi-info').style.display = 'block';
        
        this.updateSignalBars(signalStrength);
        this.log(`Detected network: ${networkName} (${signalStrength}% strength)`);
        
        // Check if within attendance range
        if (this.currentSession && distance <= this.currentSession.proximity_range) {
            this.onProximityDetected(networkName, distance);
        }
    }

    onProximityDetected(networkName, distance) {
        this.updateStatus(`In range! Distance: ${distance.toFixed(1)}m`, 'in-range');
        this.log(`Within attendance range: ${distance.toFixed(1)}m`, 'success');
        
        if (!this.attendanceMarked) {
            document.getElementById('mark-attendance').style.display = 'inline-block';
            this.showProximityNotification(networkName, distance);
        }
    }

    showProximityNotification(networkName, distance) {
        // Create notification
        const notification = document.createElement('div');
        notification.className = 'wifi-notification';
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-wifi text-success"></i>
                <div class="notification-text">
                    <strong>Classroom Detected!</strong><br>
                    You're within range of ${networkName}
                </div>
                <button class="btn btn-sm btn-success" onclick="wifiAttendance.markAttendance()">
                    Mark Attendance
                </button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-hide after 10 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 10000);
    }

    async markAttendance() {
        if (this.attendanceMarked || !this.currentSession) return;
        
        this.updateStatus('Marking attendance...', 'marking');
        
        try {
            const response = await fetch('/attendance/wifi-mark/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCSRFToken()
                },
                body: JSON.stringify({
                    session_id: this.currentSession.session_id,
                    wifi_data: {
                        network_name: document.getElementById('network-name').textContent,
                        signal_strength: this.getCurrentSignalStrength(),
                        distance: parseFloat(document.getElementById('distance').textContent),
                        timestamp: new Date().toISOString()
                    }
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.attendanceMarked = true;
                this.updateStatus('Attendance marked successfully!', 'success');
                this.log('Attendance marked via WiFi proximity', 'success');
                document.getElementById('mark-attendance').style.display = 'none';
                this.showSuccessAnimation();
                this.stopScanning();
            } else {
                this.log(`Error marking attendance: ${result.error}`, 'error');
                this.updateStatus('Failed to mark attendance', 'error');
            }
        } catch (error) {
            this.log(`Network error: ${error.message}`, 'error');
            this.updateStatus('Connection error', 'error');
        }
    }

    performProximityCheck() {
        if (!this.isScanning) return;
        
        // Simulate network strength changes
        const currentStrength = Math.floor(Math.random() * 100) + 1;
        const distance = this.calculateDistance(currentStrength);
        
        document.getElementById('distance').textContent = distance.toFixed(1);
        this.updateSignalBars(currentStrength);
        
        if (this.currentSession && distance <= this.currentSession.proximity_range && !this.attendanceMarked) {
            this.onProximityDetected(document.getElementById('network-name').textContent, distance);
        }
    }

    calculateDistance(signalStrength) {
        // Rough estimation: stronger signal = closer distance
        // This is a simplified calculation for demo purposes
        return Math.max(5, (100 - signalStrength) * 1.2);
    }

    updateSignalBars(strength) {
        const bars = document.querySelectorAll('#signal-bars .bar');
        const activeBars = Math.ceil((strength / 100) * bars.length);
        
        bars.forEach((bar, index) => {
            bar.classList.toggle('active', index < activeBars);
        });
    }

    getCurrentSignalStrength() {
        const activeBars = document.querySelectorAll('#signal-bars .bar.active').length;
        const totalBars = document.querySelectorAll('#signal-bars .bar').length;
        return Math.floor((activeBars / totalBars) * 100);
    }

    updateStatus(message, type) {
        const statusText = document.getElementById('status-text');
        const indicator = document.getElementById('status-indicator');
        
        statusText.textContent = message;
        indicator.className = `status-indicator ${type}`;
    }

    showSuccessAnimation() {
        const panel = document.querySelector('.wifi-panel');
        panel.classList.add('success-animation');
        
        setTimeout(() => {
            panel.classList.remove('success-animation');
        }, 2000);
    }

    log(message, type = 'info') {
        const logContent = document.getElementById('log-content');
        const timestamp = new Date().toLocaleTimeString();
        
        const logEntry = document.createElement('div');
        logEntry.className = `log-entry ${type}`;
        logEntry.innerHTML = `
            <span class="log-time">${timestamp}</span>
            <span class="log-message">${message}</span>
        `;
        
        logContent.insertBefore(logEntry, logContent.firstChild);
        
        // Keep only last 10 entries
        const entries = logContent.querySelectorAll('.log-entry');
        if (entries.length > 10) {
            logContent.removeChild(entries[entries.length - 1]);
        }
    }

    onConnectionChange() {
        if (this.connection) {
            this.log(`Connection changed: ${this.connection.effectiveType}`);
        }
    }

    getCSRFToken() {
        const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]');
        return csrfToken ? csrfToken.value : '';
    }
}

// Initialize WiFi attendance when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Only initialize on student dashboard or attendance pages
    if (document.querySelector('.student-dashboard') || 
        document.querySelector('[data-page="attendance"]') ||
        window.location.pathname.includes('/attendance/')) {
        window.wifiAttendance = new WiFiAttendance();
    }
});

// Add CSS styles
const wifiStyles = document.createElement('style');
wifiStyles.textContent = `
    #wifi-attendance-panel {
        margin: 2rem 0;
    }

    .wifi-panel {
        background: linear-gradient(135deg, #1a1f2e 0%, #252b3d 100%);
        border-radius: 15px;
        padding: 2rem;
        border: 1px solid rgba(99, 102, 241, 0.3);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }

    .wifi-header {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 2rem;
        color: #6366f1;
    }

    .wifi-header i {
        font-size: 2rem;
        animation: pulse 2s infinite;
    }

    .wifi-status {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1.5rem;
        padding: 1rem;
        background: rgba(99, 102, 241, 0.1);
        border-radius: 10px;
    }

    .status-indicator {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        position: relative;
        background: #6b7280;
    }

    .status-indicator.scanning {
        background: #f59e0b;
    }

    .status-indicator.found {
        background: #3b82f6;
    }

    .status-indicator.in-range {
        background: #10b981;
    }

    .status-indicator.success {
        background: #059669;
    }

    .status-indicator.error {
        background: #ef4444;
    }

    .pulse-dot {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background: inherit;
        animation: pulse-effect 2s infinite;
    }

    @keyframes pulse-effect {
        0% {
            box-shadow: 0 0 0 0 rgba(99, 102, 241, 0.7);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(99, 102, 241, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(99, 102, 241, 0);
        }
    }

    .wifi-info {
        background: rgba(15, 20, 25, 0.5);
        padding: 1.5rem;
        border-radius: 10px;
        margin-bottom: 1.5rem;
    }

    .wifi-info > div {
        margin-bottom: 1rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .signal-bars {
        display: flex;
        gap: 3px;
        align-items: end;
    }

    .signal-bars .bar {
        width: 4px;
        background: #4b5563;
        border-radius: 2px;
        transition: all 0.3s ease;
    }

    .signal-bars .bar:nth-child(1) { height: 8px; }
    .signal-bars .bar:nth-child(2) { height: 12px; }
    .signal-bars .bar:nth-child(3) { height: 16px; }
    .signal-bars .bar:nth-child(4) { height: 20px; }

    .signal-bars .bar.active {
        background: #10b981;
    }

    .wifi-actions {
        display: flex;
        gap: 1rem;
        margin-bottom: 2rem;
    }

    .wifi-log {
        background: rgba(15, 20, 25, 0.5);
        border-radius: 10px;
        overflow: hidden;
    }

    .log-header {
        padding: 1rem;
        background: rgba(99, 102, 241, 0.2);
        font-weight: 600;
        border-bottom: 1px solid rgba(99, 102, 241, 0.3);
    }

    .log-content {
        max-height: 200px;
        overflow-y: auto;
        padding: 0.5rem;
    }

    .log-entry {
        display: flex;
        gap: 1rem;
        padding: 0.5rem;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-size: 0.9rem;
    }

    .log-entry.success {
        color: #10b981;
    }

    .log-entry.error {
        color: #ef4444;
    }

    .log-time {
        color: #6b7280;
        font-size: 0.8rem;
        min-width: 80px;
    }

    .wifi-notification {
        position: fixed;
        top: 100px;
        right: 2rem;
        background: linear-gradient(135deg, #10b981, #059669);
        color: white;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(16, 185, 129, 0.3);
        z-index: 2000;
        animation: slideInRight 0.5s ease;
        max-width: 300px;
    }

    .notification-content {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .notification-text {
        flex: 1;
    }

    .wifi-panel.success-animation {
        animation: successPulse 2s ease;
    }

    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes successPulse {
        0%, 100% {
            border-color: rgba(99, 102, 241, 0.3);
        }
        50% {
            border-color: #10b981;
            box-shadow: 0 0 20px rgba(16, 185, 129, 0.5);
        }
    }
`;

document.head.appendChild(wifiStyles);