// SmartTrack Attendance JavaScript

class AttendanceManager {
    constructor() {
        this.csrfToken = SmartTrack.getCookie('csrftoken');
        this.init();
    }

    init() {
        this.bindEvents();
        this.initializeQRScanner();
        this.updateAttendanceStats();
    }

    bindEvents() {
        // QR Code Scanner Modal
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-action="scan-qr"]')) {
                this.openQRScanner();
            }
        });

        // Manual Attendance Marking
        document.addEventListener('change', (e) => {
            if (e.target.matches('[data-action="mark-attendance"]')) {
                this.markAttendance(e.target);
            }
        });

        // Attendance Session Management
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-action="start-session"]')) {
                this.startAttendanceSession(e.target);
            }
            if (e.target.matches('[data-action="end-session"]')) {
                this.endAttendanceSession(e.target);
            }
        });

        // Real-time Updates
        this.setupRealTimeUpdates();
    }

    initializeQRScanner() {
        // QR Scanner initialization would go here
        // For now, we'll use a placeholder
        document.addEventListener('shown.bs.modal', (e) => {
            if (e.target.id === 'scanModal') {
                this.setupQRReaderPlaceholder();
            }
        });
    }

    setupQRReaderPlaceholder() {
        const qrReader = document.getElementById('qr-reader');
        if (qrReader) {
            qrReader.innerHTML = `
                <div class="border rounded p-4 bg-light">
                    <div class="text-center">
                        <i class="fas fa-camera text-primary mb-3" style="font-size: 4rem;"></i>
                        <h5>QR Code Scanner</h5>
                        <p class="text-muted">Camera access required for scanning</p>
                        <button class="btn btn-primary btn-sm" onclick="attendanceManager.simulateQRScan()">
                            <i class="fas fa-qrcode me-2"></i>Simulate Scan (Demo)
                        </button>
                    </div>
                </div>
            `;
        }
    }

    simulateQRScan() {
        // Simulate a QR code scan for demo purposes
        const demoSessionId = 'demo-session-' + Date.now();
        this.processQRScan(`smarttrack://attend/${demoSessionId}`);
    }

    processQRScan(qrData) {
        const scanResult = document.getElementById('scan-result');
        
        if (qrData.includes('smarttrack://attend/')) {
            const sessionId = qrData.split('/').pop();
            this.markAttendanceByQR(sessionId);
        } else {
            this.showScanError('Invalid QR Code format');
        }
    }

    async markAttendanceByQR(sessionId) {
        try {
            const response = await fetch('/attendance/scan-attendance/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.csrfToken
                },
                body: JSON.stringify({ session_id: sessionId })
            });

            const data = await response.json();
            
            if (data.success) {
                this.showScanSuccess(data.message);
                setTimeout(() => {
                    bootstrap.Modal.getInstance(document.getElementById('scanModal')).hide();
                    location.reload();
                }, 2000);
            } else {
                this.showScanError(data.error);
            }
        } catch (error) {
            console.error('Error marking attendance:', error);
            this.showScanError('Network error occurred. Please try again.');
        }
    }

    showScanSuccess(message) {
        const scanResult = document.getElementById('scan-result');
        if (scanResult) {
            scanResult.className = 'alert alert-success';
            scanResult.innerHTML = `
                <i class="fas fa-check-circle me-2"></i>
                ${message}
            `;
            scanResult.classList.remove('d-none');
        }
        SmartTrack.showNotification(message, 'success');
    }

    showScanError(error) {
        const scanResult = document.getElementById('scan-result');
        if (scanResult) {
            scanResult.className = 'alert alert-danger';
            scanResult.innerHTML = `
                <i class="fas fa-exclamation-triangle me-2"></i>
                ${error}
            `;
            scanResult.classList.remove('d-none');
        }
        SmartTrack.showNotification(error, 'danger');
    }

    async markAttendance(element) {
        const sessionId = element.dataset.sessionId;
        const studentId = element.dataset.studentId;
        const status = element.value;

        try {
            const response = await fetch('/attendance/mark-attendance/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.csrfToken
                },
                body: JSON.stringify({
                    session_id: sessionId,
                    student_id: studentId,
                    status: status
                })
            });

            const data = await response.json();
            
            if (data.success) {
                SmartTrack.showNotification(data.message, 'success');
                this.updateAttendanceRow(element, status);
            } else {
                SmartTrack.showNotification(data.error, 'danger');
            }
        } catch (error) {
            console.error('Error marking attendance:', error);
            SmartTrack.showNotification('Error marking attendance', 'danger');
        }
    }

    updateAttendanceRow(element, status) {
        const row = element.closest('tr');
        const statusCell = row.querySelector('.attendance-status');
        
        if (statusCell) {
            let badgeClass = 'bg-secondary';
            let statusText = status;
            
            switch(status) {
                case 'present':
                    badgeClass = 'bg-success';
                    statusText = 'Present';
                    break;
                case 'late':
                    badgeClass = 'bg-warning';
                    statusText = 'Late';
                    break;
                case 'absent':
                    badgeClass = 'bg-danger';
                    statusText = 'Absent';
                    break;
            }
            
            statusCell.innerHTML = `<span class="badge ${badgeClass}">${statusText}</span>`;
        }
    }

    async startAttendanceSession(element) {
        const subjectId = element.dataset.subjectId;
        const sessionType = element.dataset.sessionType || 'qr';

        try {
            const response = await fetch('/attendance/create-session/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-CSRFToken': this.csrfToken
                },
                body: new URLSearchParams({
                    subject_id: subjectId,
                    session_type: sessionType
                })
            });

            if (response.ok) {
                const data = await response.text();
                SmartTrack.showNotification('Attendance session started!', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                throw new Error('Failed to start session');
            }
        } catch (error) {
            console.error('Error starting session:', error);
            SmartTrack.showNotification('Error starting attendance session', 'danger');
        }
    }

    async endAttendanceSession(element) {
        const sessionId = element.dataset.sessionId;

        try {
            const response = await fetch(`/attendance/session/${sessionId}/end/`, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': this.csrfToken
                }
            });

            if (response.ok) {
                SmartTrack.showNotification('Attendance session ended!', 'info');
                setTimeout(() => location.reload(), 1000);
            } else {
                throw new Error('Failed to end session');
            }
        } catch (error) {
            console.error('Error ending session:', error);
            SmartTrack.showNotification('Error ending attendance session', 'danger');
        }
    }

    updateAttendanceStats() {
        // Update real-time attendance statistics
        const statCards = document.querySelectorAll('[data-stat]');
        statCards.forEach(card => {
            const statType = card.dataset.stat;
            this.fetchAndUpdateStat(statType, card);
        });
    }

    async fetchAndUpdateStat(statType, element) {
        try {
            const response = await fetch(`/api/stats/${statType}/`);
            const data = await response.json();
            
            if (data.success) {
                const numberElement = element.querySelector('.stat-number');
                if (numberElement) {
                    this.animateNumber(numberElement, parseInt(numberElement.textContent), data.value);
                }
            }
        } catch (error) {
            console.error(`Error fetching ${statType} stat:`, error);
        }
    }

    animateNumber(element, start, end) {
        const duration = 1000;
        const startTime = performance.now();
        
        const animate = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const current = Math.floor(start + (end - start) * progress);
            element.textContent = current;
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };
        
        requestAnimationFrame(animate);
    }

    setupRealTimeUpdates() {
        // Set up periodic updates for active sessions
        setInterval(() => {
            this.updateAttendanceStats();
        }, 30000); // Update every 30 seconds
    }

    // Utility methods for attendance management
    generateAttendanceReport(sessionId) {
        window.open(`/attendance/session/${sessionId}/report/`, '_blank');
    }

    exportAttendanceData(format = 'csv') {
        const url = `/attendance/export/?format=${format}`;
        window.location.href = url;
    }
}

// Goal Management
class AttendanceGoalManager {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateGoalProgress();
    }

    bindEvents() {
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-action="update-goal"]')) {
                this.updateGoal(e.target);
            }
        });

        document.addEventListener('change', (e) => {
            if (e.target.matches('[data-goal="target"]')) {
                this.updateTargetPercentage(e.target);
            }
        });
    }

    updateGoalProgress() {
        const progressBars = document.querySelectorAll('.progress-bar[data-goal]');
        progressBars.forEach(bar => {
            const current = parseFloat(bar.dataset.current);
            const target = parseFloat(bar.dataset.target);
            const percentage = Math.min((current / target) * 100, 100);
            
            setTimeout(() => {
                bar.style.width = `${percentage}%`;
                bar.setAttribute('aria-valuenow', percentage);
            }, 500);
        });
    }

    async updateGoal(element) {
        const goalId = element.dataset.goalId;
        const targetPercentage = element.dataset.target;

        try {
            const response = await fetch('/attendance/goals/update/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': SmartTrack.getCookie('csrftoken')
                },
                body: JSON.stringify({
                    goal_id: goalId,
                    target_percentage: targetPercentage
                })
            });

            const data = await response.json();
            
            if (data.success) {
                SmartTrack.showNotification('Goal updated successfully!', 'success');
                this.updateGoalProgress();
            } else {
                SmartTrack.showNotification(data.error, 'danger');
            }
        } catch (error) {
            console.error('Error updating goal:', error);
            SmartTrack.showNotification('Error updating goal', 'danger');
        }
    }

    updateTargetPercentage(element) {
        const goalCard = element.closest('.card');
        const progressBar = goalCard.querySelector('.progress-bar');
        const targetValue = element.value;
        
        if (progressBar) {
            progressBar.dataset.target = targetValue;
            this.updateGoalProgress();
        }
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.attendanceManager = new AttendanceManager();
    window.goalManager = new AttendanceGoalManager();
    
    // Add keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl + Q to open QR scanner
        if (e.ctrlKey && e.key === 'q') {
            e.preventDefault();
            const scanBtn = document.querySelector('[data-action="scan-qr"]');
            if (scanBtn) scanBtn.click();
        }
        
        // Ctrl + R to refresh attendance data
        if (e.ctrlKey && e.key === 'r') {
            e.preventDefault();
            window.attendanceManager.updateAttendanceStats();
            SmartTrack.showNotification('Attendance data refreshed', 'info');
        }
    });
});