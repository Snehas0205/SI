// AI Delete Session JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initDeleteSession();
});

function initDeleteSession() {
    // Add confirmation before showing the main delete button
    const deleteBtn = document.querySelector('.btn-delete');
    if (deleteBtn) {
        deleteBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Simple confirmation dialog if modal is not available
            if (typeof bootstrap === 'undefined' || !document.getElementById('confirmModal')) {
                if (confirm('Are you absolutely sure you want to delete this session? This action cannot be undone.')) {
                    document.querySelector('.delete-form').submit();
                }
                return;
            }
            
            // Use modal if available (handled in template script)
        });
    }
}