// AI Preferences JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initPreferences();
});

function initPreferences() {
    // Add form validation
    const form = document.querySelector('.preferences-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            const saveBtn = document.querySelector('.btn-save');
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            saveBtn.disabled = true;
        });
    }
    
    // Enhance textarea auto-resize
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(textarea => {
        textarea.addEventListener('input', autoResize);
        autoResize.call(textarea); // Initial resize
    });
}

function autoResize() {
    this.style.height = 'auto';
    this.style.height = this.scrollHeight + 'px';
}