// ===== LANDING PAGE JAVASCRIPT =====

document.addEventListener('DOMContentLoaded', function() {
// Initialize all components
    initializeLoader();
    initializeNavigation();
    initializeScrollAnimations();
    initializeCounters();
    initializeSmoothScroll();
    initializeMobileMenu();
    initializeParallax();
    
    // Hide loader after initialization
    setTimeout(() => {
        hideLoader();
    }, 1500);
});

// ===== LOADING SCREEN =====
function initializeLoader() {
    const loadingScreen = document.getElementById('loading-screen');
    
    // Simulate loading process
    const loadingSteps = [
        'Initializing SmartTrack...',
        'Loading Components...',
        'Preparing Experience...',
        'Almost Ready...'
    ];
    
    const loadingText = document.querySelector('.loading-text');
    let currentStep = 0;
    
    const stepInterval = setInterval(() => {
        if (currentStep < loadingSteps.length) {
            loadingText.textContent = loadingSteps[currentStep];
            currentStep++;
        } else {
            clearInterval(stepInterval);
        }
    }, 300);
}

function hideLoader() {
    const loadingScreen = document.getElementById('loading-screen');
    loadingScreen.classList.add('hidden');
    
    // Remove from DOM after animation
    setTimeout(() => {
        if (loadingScreen && loadingScreen.parentNode) {
            loadingScreen.parentNode.removeChild(loadingScreen);
        }
    }, 600);
}

// ===== NAVIGATION =====
function initializeNavigation() {
    const navbar = document.getElementById('navbar');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Navbar scroll effect
    window.addEventListener('scroll', () => {
        if (window.scrollY > 100) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // Active link highlighting
    window.addEventListener('scroll', () => {
        const sections = document.querySelectorAll('section[id]');
        const scrollPosition = window.scrollY + 200;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');
            const navLink = document.querySelector(`a[href="#${sectionId}"]`);
            
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                navLinks.forEach(link => link.classList.remove('active'));
                if (navLink) navLink.classList.add('active');
            }
        });
    });
}

// ===== MOBILE MENU =====
function initializeMobileMenu() {
    const mobileToggle = document.getElementById('mobile-toggle');
    const navMenu = document.getElementById('nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Toggle mobile menu
    mobileToggle.addEventListener('click', () => {
        mobileToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
        document.body.classList.toggle('menu-open');
    });
    
    // Close mobile menu when clicking on links
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            mobileToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.classList.remove('menu-open');
        });
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', (e) => {
        if (!navMenu.contains(e.target) && !mobileToggle.contains(e.target)) {
            mobileToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.classList.remove('menu-open');
        }
    });
}

// ===== SMOOTH SCROLLING =====
function initializeSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const navbarHeight = document.getElementById('navbar').offsetHeight;
                const targetPosition = targetElement.offsetTop - navbarHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// ===== SCROLL ANIMATIONS =====
function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                
                // Trigger counter animation for stats
                if (entry.target.classList.contains('stat-number')) {
                    animateCounter(entry.target);
                }
            }
        });
    }, observerOptions);
    
    // Observe feature cards, user type cards, and stat numbers
    const animatedElements = document.querySelectorAll('.feature-card, .user-type-card, .stat-number');
    animatedElements.forEach(el => observer.observe(el));
    
    // Add staggered animation delays
    const featureCards = document.querySelectorAll('.feature-card');
    const userTypeCards = document.querySelectorAll('.user-type-card');
    
    featureCards.forEach((card, index) => {
        card.style.transitionDelay = `${index * 0.1}s`;
    });
    
    userTypeCards.forEach((card, index) => {
        card.style.transitionDelay = `${index * 0.2}s`;
    });
}

// ===== COUNTER ANIMATIONS =====
function initializeCounters() {
    const counters = document.querySelectorAll('.stat-number');
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-count'));
        counter.setAttribute('data-target', target);
        counter.textContent = '0';
    });
}

function animateCounter(element) {
    if (element.classList.contains('animated')) return;
    
    const target = parseInt(element.getAttribute('data-count'));
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;
    
    element.classList.add('animated');
    
    const updateCounter = () => {
        if (current < target) {
            current += step;
            if (current > target) current = target;
            element.textContent = Math.floor(current).toLocaleString();
            requestAnimationFrame(updateCounter);
        }
    };
    
    updateCounter();
}

// ===== PARALLAX EFFECTS =====
function initializeParallax() {
    const floatingElements = document.querySelectorAll('.floating-circle');
    
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const parallax = scrolled * 0.5;
        
        floatingElements.forEach((element, index) => {
            const speed = 0.2 + (index * 0.1);
            const yPos = -(scrolled * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
    });
}

// ===== BUTTON ANIMATIONS =====
function initializeButtonAnimations() {
    const buttons = document.querySelectorAll('.btn');
    
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px) scale(1.05)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
        
        button.addEventListener('mousedown', function() {
            this.style.transform = 'translateY(0) scale(0.98)';
        });
        
        button.addEventListener('mouseup', function() {
            this.style.transform = 'translateY(-2px) scale(1.05)';
        });
    });
}

// ===== PERFORMANCE OPTIMIZATIONS =====

// Throttle scroll events for better performance
function throttle(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply throttling to scroll events
const throttledScrollHandler = throttle(() => {
    // Update navbar state
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 100) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
}, 16);

window.addEventListener('scroll', throttledScrollHandler);

// ===== ACCESSIBILITY FEATURES =====

// Keyboard navigation support
document.addEventListener('keydown', function(e) {
    // Handle Enter key on buttons and links
    if (e.key === 'Enter' && e.target.matches('button, a')) {
        e.target.click();
    }
    
    // Handle Escape key to close mobile menu
    if (e.key === 'Escape') {
        const mobileToggle = document.getElementById('mobile-toggle');
        const navMenu = document.getElementById('nav-menu');
        
        if (navMenu.classList.contains('active')) {
            mobileToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.classList.remove('menu-open');
        }
    }
});

// Reduce motion for accessibility
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

if (prefersReducedMotion.matches) {
    // Disable animations for users who prefer reduced motion
    document.documentElement.style.setProperty('--transition-fast', '0s');
    document.documentElement.style.setProperty('--transition-normal', '0s');
    document.documentElement.style.setProperty('--transition-slow', '0s');
}

// ===== FORM ENHANCEMENTS =====

// Add form validation and enhancement if forms are present
function enhanceForms() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            // Add floating label effect
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentElement.classList.remove('focused');
                }
            });
            
            // Pre-fill check
            if (input.value) {
                input.parentElement.classList.add('focused');
            }
        });
    });
}

// ===== ERROR HANDLING =====

// Global error handler
window.addEventListener('error', function(e) {
    console.warn('SmartTrack: Non-critical error occurred:', e.error);
});

// Handle unhandled promise rejections
window.addEventListener('unhandledrejection', function(e) {
    console.warn('SmartTrack: Promise rejection:', e.reason);
});

// ===== ANALYTICS AND TRACKING =====

// Track user interactions (can be extended with actual analytics)
function trackEvent(eventName, eventData = {}) {
    // This is a placeholder for analytics integration
    console.log('Event tracked:', eventName, eventData);
    
    // Example: Google Analytics 4 event tracking
    // gtag('event', eventName, eventData);
    
    // Example: Custom analytics
    // analytics.track(eventName, eventData);
}

// Track button clicks
document.addEventListener('click', function(e) {
    if (e.target.matches('.btn, button')) {
        const buttonText = e.target.textContent.trim();
        const buttonClass = e.target.className;
        
        trackEvent('button_click', {
            button_text: buttonText,
            button_class: buttonClass,
            page_location: window.location.href
        });
    }
});

// Track navigation usage
document.addEventListener('click', function(e) {
    if (e.target.matches('.nav-link')) {
        const linkText = e.target.textContent.trim();
        const linkHref = e.target.getAttribute('href');
        
        trackEvent('navigation_click', {
            link_text: linkText,
            link_href: linkHref
        });
    }
});

// ===== UTILITY FUNCTIONS =====

// Check if element is in viewport
function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// Debounce function for performance
function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            timeout = null;
            if (!immediate) func(...args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func(...args);
    };
}

// ===== INITIALIZATION COMPLETE =====
console.log('SmartTrack Landing Page: Initialization complete');

// Expose useful functions globally for debugging
window.SmartTrack = {
    trackEvent,
    isInViewport,
    debounce,
    throttle,
    hideLoader,
    animateCounter
};
