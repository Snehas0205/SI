// Student Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('Student Dashboard loaded successfully!');
    
    // Initialize dashboard components
    initializeQRScanner();
    initializeModalHandlers();
    initializeStatCards();
    updateDateTime();
    initializeProgressBars();
    
    // Update time every minute
    setInterval(updateDateTime, 60000);
});

// QR Code Scanner functionality
function initializeQRScanner() {
    const scanModal = document.getElementById('scanModal');
    const scanButton = document.querySelector('[data-action="scan-qr"]');
    
    if (scanButton) {
        scanButton.addEventListener('click', function() {
            showModal('scanModal');
            startQRScanner();
        });
    }
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        modal.style.display = 'block';
        document.body.classList.add('modal-open');
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        modal.style.display = 'none';
        document.body.classList.remove('modal-open');
    }
}

function startQRScanner() {
    const qrReaderDiv = document.getElementById('qr-reader');
    const scanResult = document.getElementById('scan-result');
    
    if (typeof Html5Qrcode !== 'undefined') {
        const html5QrCode = new Html5Qrcode("qr-reader");
        
        const qrCodeSuccessCallback = (decodedText, decodedResult) => {
            console.log(`QR Code detected: ${decodedText}`);
            
            // Show success message
            scanResult.textContent = `QR Code detected: ${decodedText}`;
            scanResult.className = 'alert alert-success';
            scanResult.classList.remove('d-none');
            
            // Stop scanning
            html5QrCode.stop().then(() => {
                console.log('QR Code scanning stopped.');
                
                // Process the QR code (you can add your attendance logic here)
                processAttendanceQR(decodedText);
                
                // Close modal after 2 seconds
                setTimeout(() => {
                    hideModal('scanModal');
                    scanResult.classList.add('d-none');
                }, 2000);
            }).catch(err => {
                console.error('Error stopping QR scanner:', err);
            });
        };
        
        const config = {
            fps: 10,
            qrbox: { width: 250, height: 250 },
            aspectRatio: 1.0
        };
        
        html5QrCode.start(
            { facingMode: "environment" },
            config,
            qrCodeSuccessCallback,
            (errorMessage) => {
                // Handle scan errors silently
            }
        ).catch(err => {
            console.error('Error starting QR scanner:', err);
            scanResult.textContent = 'Error accessing camera. Please check permissions.';
            scanResult.className = 'alert alert-danger';
            scanResult.classList.remove('d-none');
        });
    } else {
        scanResult.textContent = 'QR Scanner library not loaded.';
        scanResult.className = 'alert alert-warning';
        scanResult.classList.remove('d-none');
    }
}

function processAttendanceQR(qrData) {
    // Simulate attendance processing
    console.log('Processing attendance for:', qrData);
    
    // You can add AJAX call here to submit attendance
    // For now, just show a success message
    showNotification('Attendance marked successfully!', 'success');
}

// Modal handlers
function initializeModalHandlers() {
    // Close modal when clicking close button
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('btn-close')) {
            const modal = e.target.closest('.modal');
            if (modal) {
                hideModal(modal.id);
            }
        }
        
        // Close modal when clicking backdrop
        if (e.target.classList.contains('modal')) {
            hideModal(e.target.id);
        }
    });
    
    // Close modal on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const openModals = document.querySelectorAll('.modal.show');
            openModals.forEach(modal => {
                hideModal(modal.id);
            });
        }
    });
}

// Animate stat cards on page load
function initializeStatCards() {
    const statCards = document.querySelectorAll('.stat-card');
    
    // Add initial animation
    statCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.6s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
    
    // Add click animation
    statCards.forEach(card => {
        card.addEventListener('click', function() {
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'translateY(0) scale(1)';
            }, 150);
        });
    });
}

// Update date and time display
function updateDateTime() {
    const dateElements = document.querySelectorAll('[data-date]');
    const now = new Date();
    
    const options = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    };
    
    const dateString = now.toLocaleDateString('en-US', options);
    
    dateElements.forEach(element => {
        element.textContent = dateString;
    });
}

// Animate progress bars
function initializeProgressBars() {
    const progressBars = document.querySelectorAll('.progress-bar');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const progressBar = entry.target;
                const width = progressBar.style.width;
                progressBar.style.width = '0%';
                
                setTimeout(() => {
                    progressBar.style.width = width;
                }, 100);
            }
        });
    }, { threshold: 0.1 });
    
    progressBars.forEach(bar => {
        observer.observe(bar);
    });
}

// Navigation link active state
function updateActiveNavLink() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} notification`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        animation: slideIn 0.3s ease;
    `;
    
    // Add animation styles
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        .notification {
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}

// Handle sidebar navigation on mobile
function initializeMobileNavigation() {
    const sidebar = document.querySelector('.sidebar');
    const navLinks = document.querySelectorAll('.nav-link');
    
    if (window.innerWidth <= 992) {
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                // Close sidebar on mobile after clicking a link
                if (sidebar) {
                    sidebar.style.display = 'none';
                }
            });
        });
    }
}

// Refresh data functionality
function refreshDashboardData() {
    // Add loading states to cards
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.style.opacity = '0.6';
    });
    
    // Simulate data refresh (replace with actual API call)
    setTimeout(() => {
        cards.forEach(card => {
            card.style.opacity = '1';
        });
        showNotification('Dashboard data refreshed', 'success');
    }, 1500);
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + R for refresh
    if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
        e.preventDefault();
        refreshDashboardData();
    }
    
    // Ctrl/Cmd + S for scan QR
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        const scanButton = document.querySelector('[data-action="scan-qr"]');
        if (scanButton) {
            scanButton.click();
        }
    }
});

// Initialize mobile navigation
initializeMobileNavigation();

// Call update active nav link on load
updateActiveNavLink();