// AI Career Guidance Engine
class AICareerEngine {
    constructor() {
        this.studentData = {};
        this.careerDatabase = [];
        this.aiModels = {};
        this.recommendations = [];
        this.init();
    }

    init() {
        this.setupCareerDatabase();
        this.setupAIModels();
        this.loadStudentData();
    }

    setupCareerDatabase() {
        // Comprehensive career database with requirements and trends
        this.careerDatabase = [
            {
                id: 'software_engineer',
                title: 'Software Engineer',
                category: 'Technology',
                description: 'Design, develop, and maintain software applications',
                requirements: {
                    subjects: ['mathematics', 'computer_science', 'physics'],
                    skills: ['programming', 'problem_solving', 'logical_thinking'],
                    minGPA: 3.0
                },
                salaryRange: '$70,000 - $150,000',
                growthRate: 22,
                demandLevel: 'Very High',
                icon: 'fas fa-code',
                color: 'primary'
            },
            {
                id: 'data_scientist',
                title: 'Data Scientist',
                category: 'Technology',
                description: 'Analyze complex data to help organizations make decisions',
                requirements: {
                    subjects: ['mathematics', 'statistics', 'computer_science'],
                    skills: ['analytics', 'programming', 'statistics'],
                    minGPA: 3.2
                },
                salaryRange: '$85,000 - $170,000',
                growthRate: 31,
                demandLevel: 'Very High',
                icon: 'fas fa-chart-line',
                color: 'success'
            },
            {
                id: 'doctor',
                title: 'Medical Doctor',
                category: 'Healthcare',
                description: 'Diagnose and treat illnesses and injuries',
                requirements: {
                    subjects: ['biology', 'chemistry', 'physics', 'mathematics'],
                    skills: ['empathy', 'problem_solving', 'attention_to_detail'],
                    minGPA: 3.7
                },
                salaryRange: '$200,000 - $400,000',
                growthRate: 4,
                demandLevel: 'High',
                icon: 'fas fa-stethoscope',
                color: 'danger'
            },
            {
                id: 'teacher',
                title: 'Educator',
                category: 'Education',
                description: 'Educate and inspire the next generation',
                requirements: {
                    subjects: ['education', 'psychology', 'subject_specialization'],
                    skills: ['communication', 'patience', 'leadership'],
                    minGPA: 2.8
                },
                salaryRange: '$40,000 - $70,000',
                growthRate: 8,
                demandLevel: 'Medium',
                icon: 'fas fa-chalkboard-teacher',
                color: 'info'
            },
            {
                id: 'engineer',
                title: 'Engineer',
                category: 'Engineering',
                description: 'Design and build systems, structures, and machines',
                requirements: {
                    subjects: ['mathematics', 'physics', 'chemistry'],
                    skills: ['problem_solving', 'creativity', 'technical_thinking'],
                    minGPA: 3.0
                },
                salaryRange: '$65,000 - $120,000',
                growthRate: 6,
                demandLevel: 'High',
                icon: 'fas fa-cogs',
                color: 'warning'
            },
            {
                id: 'business_analyst',
                title: 'Business Analyst',
                category: 'Business',
                description: 'Analyze business processes and recommend improvements',
                requirements: {
                    subjects: ['business', 'mathematics', 'economics'],
                    skills: ['analysis', 'communication', 'problem_solving'],
                    minGPA: 3.0
                },
                salaryRange: '$60,000 - $100,000',
                growthRate: 14,
                demandLevel: 'High',
                icon: 'fas fa-briefcase',
                color: 'secondary'
            }
        ];
    }

    setupAIModels() {
        // Simulate AI models for different aspects of career guidance
        this.aiModels = {
            academicPerformanceModel: this.createAcademicModel(),
            personalityModel: this.createPersonalityModel(),
            marketTrendsModel: this.createMarketTrendsModel(),
            skillsAssessmentModel: this.createSkillsModel()
        };
    }

    createAcademicModel() {
        return {
            analyze: (grades, subjects) => {
                const performance = {};
                for (let subject of subjects) {
                    const subjectGrades = grades.filter(g => g.subject === subject);
                    const average = subjectGrades.length > 0 
                        ? subjectGrades.reduce((sum, g) => sum + g.score, 0) / subjectGrades.length
                        : 0;
                    performance[subject] = {
                        average: average,
                        trend: this.calculateTrend(subjectGrades),
                        strength: average > 85 ? 'high' : average > 70 ? 'medium' : 'low'
                    };
                }
                return performance;
            }
        };
    }

    createPersonalityModel() {
        return {
            analyze: (responses) => {
                // Simulate personality analysis based on responses
                const traits = {
                    analytical: Math.random() * 10,
                    creative: Math.random() * 10,
                    social: Math.random() * 10,
                    leadership: Math.random() * 10,
                    technical: Math.random() * 10
                };
                return traits;
            }
        };
    }

    createMarketTrendsModel() {
        return {
            analyze: () => {
                return {
                    trending: ['ai', 'data_science', 'cybersecurity', 'healthcare', 'renewable_energy'],
                    declining: ['traditional_manufacturing', 'print_media'],
                    emerging: ['quantum_computing', 'biotechnology', 'space_technology']
                };
            }
        };
    }

    createSkillsModel() {
        return {
            assess: (activities, projects) => {
                const skills = {
                    technical: 0,
                    communication: 0,
                    leadership: 0,
                    creativity: 0,
                    problem_solving: 0
                };

                // Simulate skill assessment based on activities
                activities.forEach(activity => {
                    if (activity.type === 'technical') skills.technical += 2;
                    if (activity.type === 'presentation') skills.communication += 2;
                    if (activity.type === 'leadership') skills.leadership += 2;
                    if (activity.type === 'creative') skills.creativity += 2;
                });

                return skills;
            }
        };
    }

    async loadStudentData() {
        try {
            // In a real implementation, this would load from the backend
            const response = await fetch('/career/api/student-data/', {
                headers: {
                    'X-CSRFToken': this.getCSRFToken()
                }
            });
            
            if (response.ok) {
                this.studentData = await response.json();
            } else {
                // Simulate student data for demo
                this.studentData = this.generateMockStudentData();
            }
        } catch (error) {
            console.log('Using mock data for career guidance');
            this.studentData = this.generateMockStudentData();
        }
    }

    generateMockStudentData() {
        return {
            grades: [
                { subject: 'mathematics', score: 88, date: '2024-01-15' },
                { subject: 'computer_science', score: 92, date: '2024-01-20' },
                { subject: 'physics', score: 85, date: '2024-01-25' },
                { subject: 'english', score: 78, date: '2024-01-30' },
                { subject: 'biology', score: 82, date: '2024-02-05' }
            ],
            subjects: ['mathematics', 'computer_science', 'physics', 'english', 'biology'],
            activities: [
                { type: 'technical', name: 'Programming Club', duration: 6 },
                { type: 'leadership', name: 'Student Council', duration: 12 },
                { type: 'creative', name: 'Art Club', duration: 3 }
            ],
            interests: ['technology', 'problem_solving', 'innovation'],
            personalityType: 'analytical',
            gpa: 3.6
        };
    }

    async generateRecommendations() {
        const academicAnalysis = this.aiModels.academicPerformanceModel.analyze(
            this.studentData.grades, 
            this.studentData.subjects
        );

        const personalityTraits = this.aiModels.personalityModel.analyze([]);
        const marketTrends = this.aiModels.marketTrendsModel.analyze();
        const skillsAssessment = this.aiModels.skillsAssessmentModel.assess(
            this.studentData.activities, 
            []
        );

        // AI-powered career matching algorithm
        this.recommendations = this.careerDatabase.map(career => {
            let score = this.calculateCompatibilityScore(
                career, 
                academicAnalysis, 
                personalityTraits, 
                skillsAssessment, 
                marketTrends
            );

            return {
                ...career,
                compatibilityScore: score,
                confidence: Math.min(100, score * 10),
                reasons: this.generateRecommendationReasons(career, academicAnalysis, personalityTraits),
                nextSteps: this.generateNextSteps(career, academicAnalysis)
            };
        }).sort((a, b) => b.compatibilityScore - a.compatibilityScore);

        return this.recommendations.slice(0, 6); // Top 6 recommendations
    }

    calculateCompatibilityScore(career, academic, personality, skills, trends) {
        let score = 0;
        let maxScore = 10;

        // Academic performance match
        let academicMatch = 0;
        for (let subject of career.requirements.subjects) {
            if (academic[subject]) {
                academicMatch += academic[subject].average / 100;
            }
        }
        score += (academicMatch / career.requirements.subjects.length) * 3;

        // GPA requirement
        if (this.studentData.gpa >= career.requirements.minGPA) {
            score += 2;
        } else {
            score += (this.studentData.gpa / career.requirements.minGPA) * 2;
        }

        // Market trends boost
        if (trends.trending.some(trend => career.category.toLowerCase().includes(trend))) {
            score += 1.5;
        }

        // Demand level multiplier
        const demandMultiplier = {
            'Very High': 1.2,
            'High': 1.1,
            'Medium': 1.0,
            'Low': 0.9
        };
        score *= demandMultiplier[career.demandLevel] || 1.0;

        // Growth rate bonus
        if (career.growthRate > 15) {
            score += 0.5;
        }

        return Math.min(10, score);
    }

    generateRecommendationReasons(career, academic, personality) {
        const reasons = [];

        // Academic strengths
        for (let subject of career.requirements.subjects) {
            if (academic[subject] && academic[subject].strength === 'high') {
                reasons.push(`Strong performance in ${subject} (${academic[subject].average.toFixed(1)}%)`);
            }
        }

        // Market trends
        if (career.growthRate > 15) {
            reasons.push(`High growth rate (${career.growthRate}% projected growth)`);
        }

        if (career.demandLevel === 'Very High' || career.demandLevel === 'High') {
            reasons.push(`${career.demandLevel.toLowerCase()} market demand`);
        }

        // Personality fit (simulated)
        reasons.push(`Good personality fit for ${career.category.toLowerCase()} field`);

        return reasons.slice(0, 3); // Top 3 reasons
    }

    generateNextSteps(career, academic) {
        const steps = [];

        // Academic improvements
        for (let subject of career.requirements.subjects) {
            if (academic[subject] && academic[subject].strength === 'low') {
                steps.push(`Improve ${subject} performance (currently ${academic[subject].average.toFixed(1)}%)`);
            }
        }

        // Skill development
        steps.push(`Develop ${career.requirements.skills.join(', ')} skills`);

        // Experience
        steps.push(`Gain experience through internships or projects in ${career.category}`);

        // Networking
        steps.push(`Connect with professionals in ${career.title} field`);

        return steps.slice(0, 4); // Top 4 steps
    }

    calculateTrend(grades) {
        if (grades.length < 2) return 'stable';
        
        const recent = grades.slice(-3).map(g => g.score);
        const older = grades.slice(0, -3).map(g => g.score);
        
        const recentAvg = recent.reduce((sum, score) => sum + score, 0) / recent.length;
        const olderAvg = older.length > 0 ? older.reduce((sum, score) => sum + score, 0) / older.length : recentAvg;
        
        const difference = recentAvg - olderAvg;
        
        if (difference > 5) return 'improving';
        if (difference < -5) return 'declining';
        return 'stable';
    }

    async saveCareerGoal(careerGoal) {
        try {
            const response = await fetch('/career/api/save-goal/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCSRFToken()
                },
                body: JSON.stringify({
                    career_goal: careerGoal,
                    timestamp: new Date().toISOString()
                })
            });

            return await response.json();
        } catch (error) {
            console.error('Error saving career goal:', error);
            return { success: false, error: error.message };
        }
    }

    async generatePersonalizedTasks(careerPath) {
        const career = this.careerDatabase.find(c => c.id === careerPath);
        if (!career) return [];

        const tasks = [];

        // Academic improvement tasks
        for (let subject of career.requirements.subjects) {
            tasks.push({
                title: `Improve ${subject} grade`,
                description: `Focus on ${subject} to meet career requirements`,
                type: 'academic',
                priority: 'high',
                estimatedTime: 120, // minutes
                dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 1 week
            });
        }

        // Skill development tasks
        for (let skill of career.requirements.skills) {
            tasks.push({
                title: `Develop ${skill} skills`,
                description: `Practice and improve ${skill} through projects and exercises`,
                type: 'skill_development',
                priority: 'medium',
                estimatedTime: 90,
                dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000) // 2 weeks
            });
        }

        // Research tasks
        tasks.push({
            title: `Research ${career.title} career path`,
            description: `Learn about job market, requirements, and opportunities`,
            type: 'research',
            priority: 'medium',
            estimatedTime: 60,
            dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000) // 3 days
        });

        return tasks.slice(0, 5); // Top 5 tasks
    }

    getCSRFToken() {
        const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]');
        return csrfToken ? csrfToken.value : '';
    }

    // Career exploration and planning methods
    async exploreCareer(careerId) {
        const career = this.careerDatabase.find(c => c.id === careerId);
        if (!career) return null;

        return {
            ...career,
            relatedCareers: this.findRelatedCareers(career),
            educationPath: this.generateEducationPath(career),
            skillGaps: this.identifySkillGaps(career),
            marketInsights: await this.getMarketInsights(career)
        };
    }

    findRelatedCareers(career) {
        return this.careerDatabase
            .filter(c => c.category === career.category && c.id !== career.id)
            .slice(0, 3);
    }

    generateEducationPath(career) {
        const paths = {
            'software_engineer': ['Bachelor in Computer Science', 'Coding Bootcamp', 'Online Certifications'],
            'data_scientist': ['Bachelor in Statistics/Math', 'Master in Data Science', 'ML Certifications'],
            'doctor': ['Pre-med Bachelor', 'Medical School', 'Residency Program'],
            'teacher': ['Bachelor in Education', 'Teaching License', 'Subject Certification'],
            'engineer': ['Bachelor in Engineering', 'Professional Engineering License'],
            'business_analyst': ['Bachelor in Business', 'MBA', 'Analytics Certification']
        };

        return paths[career.id] || ['Relevant Bachelor Degree', 'Professional Certification'];
    }

    identifySkillGaps(career) {
        const requiredSkills = career.requirements.skills;
        const currentSkills = Object.keys(this.aiModels.skillsAssessmentModel.assess(this.studentData.activities, []));
        
        return requiredSkills.filter(skill => !currentSkills.includes(skill));
    }

    async getMarketInsights(career) {
        // Simulate market data
        return {
            jobOpenings: Math.floor(Math.random() * 10000) + 1000,
            averageSalary: career.salaryRange,
            topEmployers: ['Google', 'Microsoft', 'Apple', 'Amazon', 'Meta'],
            requiredExperience: '0-3 years',
            remoteWorkAvailable: Math.random() > 0.3
        };
    }
}

// Initialize AI Career Engine
let aiCareerEngine;

document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.includes('/career/') || 
        document.querySelector('[data-page="career"]')) {
        aiCareerEngine = new AICareerEngine();
    }
});

// Export for global access
window.AICareerEngine = AICareerEngine;