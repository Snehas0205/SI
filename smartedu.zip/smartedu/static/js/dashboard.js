// Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Auto-refresh functionality
    let refreshTimer;
    const refreshInterval = 30000; // 30 seconds
    let refreshIndicator;

    // Create refresh indicator
    createRefreshIndicator();

    // Start auto-refresh
    startAutoRefresh();

    // Add event listeners for user activity
    ['click', 'keypress', 'scroll', 'mousemove'].forEach(event => {
        document.addEventListener(event, resetRefreshTimer);
    });

    console.log('Dashboard loaded successfully!');
});

function createRefreshIndicator() {
    const indicator = document.createElement('div');
    indicator.className = 'refresh-indicator';
    indicator.innerHTML = '<i class="fas fa-sync-alt me-2"></i>Auto-refreshing...';
    document.body.appendChild(indicator);
    refreshIndicator = indicator;
}

function startAutoRefresh() {
    refreshTimer = setTimeout(() => {
        showRefreshIndicator();
        setTimeout(() => {
            location.reload();
        }, 1000);
    }, 30000); // 30 seconds
}

function resetRefreshTimer() {
    clearTimeout(refreshTimer);
    hideRefreshIndicator();
    startAutoRefresh();
}

function showRefreshIndicator() {
    if (refreshIndicator) {
        refreshIndicator.classList.add('show');
    }
}

function hideRefreshIndicator() {
    if (refreshIndicator) {
        refreshIndicator.classList.remove('show');
    }
}

// Animate role cards on load
function animateRoleCards() {
    const roleCards = document.querySelectorAll('.role-card');
    roleCards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
}

// Initialize card animations
setTimeout(animateRoleCards, 500);