// Teacher Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Start session functionality
    const startSessionButtons = document.querySelectorAll('[data-action="start-session"]');
    startSessionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const subjectId = this.getAttribute('data-subject-id');
            const sessionType = this.getAttribute('data-session-type');
            
            // Show confirmation modal or redirect to create session
            window.location.href = `/attendance/create-session/?subject=${subjectId}&type=${sessionType}`;
        });
    });

    // End session functionality
    const endSessionButtons = document.querySelectorAll('[data-action="end-session"]');
    endSessionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const sessionId = this.getAttribute('data-session-id');
            
            if (confirm('Are you sure you want to end this session?')) {
                endAttendanceSession(sessionId);
            }
        });
    });

    // Auto-refresh active sessions every 30 seconds
    setInterval(refreshActiveSessions, 30000);

    console.log('Teacher dashboard loaded successfully!');
});

function endAttendanceSession(sessionId) {
    fetch('/attendance/end-session/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        },
        body: JSON.stringify({
            session_id: sessionId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('Session ended successfully!', 'success');
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showAlert(data.error || 'Failed to end session', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('An error occurred while ending the session', 'error');
    });
}

function refreshActiveSessions() {
    // This would be implemented to refresh the active sessions section
    // For now, we'll just log that it's running
    console.log('Refreshing active sessions...');
}

function getCSRFToken() {
    return document.querySelector('[name=csrfmiddlewaretoken]')?.value || '';
}

function showAlert(message, type = 'info') {
    // Create and show bootstrap alert
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insert at top of main content
    const mainContent = document.querySelector('.col-lg-9');
    if (mainContent) {
        mainContent.insertBefore(alertDiv, mainContent.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
}