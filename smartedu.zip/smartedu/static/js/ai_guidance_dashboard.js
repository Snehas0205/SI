// AI Guidance Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard functionality
    initGuidanceTypeSelection();
    initQuickStartForm();
    initSuggestionButtons();
});

function initGuidanceTypeSelection() {
    const guidanceTypeItems = document.querySelectorAll('.guidance-type-item');
    const guidanceTypeSelect = document.getElementById('guidance_type');
    
    if (!guidanceTypeItems.length || !guidanceTypeSelect) return;
    
    guidanceTypeItems.forEach(item => {
        item.addEventListener('click', function() {
            const type = this.dataset.type;
            if (type && guidanceTypeSelect) {
                guidanceTypeSelect.value = type;
                
                // Visual feedback
                guidanceTypeItems.forEach(i => i.classList.remove('selected'));
                this.classList.add('selected');
                
                // Scroll to form
                document.querySelector('.quick-start-form').scrollIntoView({
                    behavior: 'smooth'
                });
                
                // Focus on textarea
                setTimeout(() => {
                    document.getElementById('initial_query').focus();
                }, 300);
            }
        });
    });
}

function initQuickStartForm() {
    const form = document.querySelector('.quick-start-form');
    const textarea = document.getElementById('initial_query');
    const submitButton = document.querySelector('.btn-start');
    
    if (!form || !textarea || !submitButton) return;
    
    // Auto-resize textarea
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = this.scrollHeight + 'px';
        
        // Enable/disable submit button based on content
        if (this.value.trim()) {
            submitButton.disabled = false;
            submitButton.classList.remove('disabled');
        } else {
            submitButton.disabled = true;
            submitButton.classList.add('disabled');
        }
    });
    
    // Handle form submission
    form.addEventListener('submit', function(e) {
        const query = textarea.value.trim();
        if (!query) {
            e.preventDefault();
            showAlert('Please enter your question or topic.', 'warning');
            textarea.focus();
            return;
        }
        
        // Show loading state
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Starting...';
        submitButton.disabled = true;
    });
    
    // Handle Enter key (Shift+Enter for new line)
    textarea.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (this.value.trim()) {
                form.submit();
            }
        }
    });
}

function initSuggestionButtons() {
    // Add click handlers for any suggestion buttons that might be added dynamically
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('suggestion-btn')) {
            const suggestion = e.target.textContent.trim();
            const textarea = document.getElementById('initial_query');
            
            if (textarea && suggestion) {
                textarea.value = suggestion;
                textarea.dispatchEvent(new Event('input')); // Trigger input event
                textarea.focus();
                
                // Scroll to form
                textarea.scrollIntoView({ behavior: 'smooth' });
            }
        }
    });
}

function showAlert(message, type = 'info') {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll('.alert-dynamic');
    existingAlerts.forEach(alert => alert.remove());
    
    // Create new alert
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dynamic`;
    alert.innerHTML = `
        <i class="fas fa-${type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
        ${message}
        <button type="button" class="btn-close" onclick="this.parentElement.remove()">
            <span>&times;</span>
        </button>
    `;
    
    // Insert at top of container
    const container = document.querySelector('.ai-guidance-container');
    if (container) {
        container.insertBefore(alert, container.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (alert.parentElement) {
                alert.remove();
            }
        }, 5000);
    }
}

// Add some interactive enhancements
function enhanceDashboard() {
    // Add loading states for session links
    const sessionLinks = document.querySelectorAll('a[href*="session_detail"]');
    sessionLinks.forEach(link => {
        link.addEventListener('click', function() {
            const button = this.querySelector('.btn');
            if (button) {
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            }
        });
    });
    
    // Add tooltips for guidance type badges
    const badges = document.querySelectorAll('.guidance-type-badge');
    badges.forEach(badge => {
        badge.title = `${badge.textContent} session`;
    });
    
    // Enhance empty states with call-to-action
    const emptyStates = document.querySelectorAll('.empty-state');
    emptyStates.forEach(state => {
        const focusButton = document.createElement('button');
        focusButton.className = 'btn btn-outline-primary btn-sm mt-2';
        focusButton.textContent = 'Start Your First Session';
        focusButton.onclick = () => {
            document.getElementById('initial_query').focus();
            document.querySelector('.quick-start-form').scrollIntoView({ behavior: 'smooth' });
        };
        state.appendChild(focusButton);
    });
}

// Initialize enhancements when DOM is ready
document.addEventListener('DOMContentLoaded', enhanceDashboard);

// Add CSS for dynamic elements
const style = document.createElement('style');
style.textContent = `
    .guidance-type-item.selected {
        border-color: #3498db !important;
        background-color: #f8fbfe !important;
        transform: translateY(-2px);
    }
    
    .alert-dynamic {
        position: relative;
        animation: slideDown 0.3s ease-out;
    }
    
    .btn-close {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        font-size: 1.2rem;
        cursor: pointer;
        opacity: 0.7;
    }
    
    .btn-close:hover {
        opacity: 1;
    }
    
    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .btn-start.disabled,
    .btn-start:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        transform: none;
    }
`;
document.head.appendChild(style);