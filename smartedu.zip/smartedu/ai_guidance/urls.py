from django.urls import path
from . import views

app_name = 'ai_guidance'

urlpatterns = [
    # Dashboard and main views
    path('', views.guidance_dashboard, name='dashboard'),
    path('start/', views.start_session, name='start_session'),
    
    # Session management
    path('sessions/', views.session_list, name='session_list'),
    path('session/<int:session_id>/', views.session_detail, name='session_detail'),
    path('session/<int:session_id>/delete/', views.delete_session, name='delete_session'),
    
    # API endpoints
    path('session/<int:session_id>/send/', views.send_message, name='send_message'),
    path('suggestions/<str:guidance_type>/', views.get_suggestions, name='get_suggestions'),
    
    # User preferences
    path('preferences/', views.preferences, name='preferences'),
]