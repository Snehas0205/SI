from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone
import json
import logging

from .models import GuidanceSession, GuidanceMessage, UserGuidancePreferences
from .ai_service import AIGuidanceService

logger = logging.getLogger(__name__)

@login_required
def guidance_dashboard(request):
    """Main AI guidance dashboard"""
    # Get user's recent sessions
    sessions = GuidanceSession.objects.filter(user=request.user).order_by('-updated_at')[:5]
    
    # Get user preferences
    try:
        preferences = request.user.guidance_preferences
    except UserGuidancePreferences.DoesNotExist:
        preferences = None
    
    # Check if AI service is available
    try:
        ai_service = AIGuidanceService()
        ai_available = ai_service.is_available()
    except Exception as e:
        logger.warning(f"AI service initialization failed: {str(e)}")
        ai_available = False
    
    context = {
        'sessions': sessions,
        'preferences': preferences,
        'ai_available': ai_available,
        'guidance_types': GuidanceSession.GUIDANCE_TYPES,
    }
    
    return render(request, 'ai_guidance_dashboard.html', context)

@login_required
def start_session(request):
    """Start a new AI guidance session"""
    if request.method == 'POST':
        guidance_type = request.POST.get('guidance_type', 'general')
        initial_query = request.POST.get('initial_query', '').strip()
        
        if not initial_query:
            messages.error(request, 'Please enter your question or topic.')
            return redirect('ai_guidance:dashboard')
        
        # Create new session
        ai_service = AIGuidanceService()
        if guidance_type == 'auto':
            guidance_type = ai_service.analyze_user_query(initial_query)
        
        session = GuidanceSession.objects.create(
            user=request.user,
            guidance_type=guidance_type,
            title=initial_query[:100],  # Use first 100 chars as title
            initial_query=initial_query
        )
        
        # Save user message
        GuidanceMessage.objects.create(
            session=session,
            message_type='user',
            content=initial_query
        )
        
        return redirect('ai_guidance:session_detail', session_id=session.id)
    
    # GET request - show start session form
    ai_service = AIGuidanceService()
    context = {
        'guidance_types': GuidanceSession.GUIDANCE_TYPES,
        'ai_available': ai_service.is_available(),
    }
    
    return render(request, 'ai_guidance_start.html', context)

@login_required
def session_detail(request, session_id):
    """View detailed AI guidance session"""
    session = get_object_or_404(GuidanceSession, id=session_id, user=request.user)
    messages_list = session.messages.all().order_by('timestamp')
    
    # Get AI suggestions for this type
    ai_service = AIGuidanceService()
    suggestions = ai_service.get_suggested_questions(session.guidance_type)
    
    context = {
        'session': session,
        'messages': messages_list,
        'suggestions': suggestions,
        'ai_available': ai_service.is_available(),
    }
    
    return render(request, 'ai_session_chat.html', context)

@login_required
@require_POST
@csrf_exempt
def send_message(request, session_id):
    """Send a message in AI guidance session (AJAX endpoint)"""
    try:
        session = get_object_or_404(GuidanceSession, id=session_id, user=request.user)
        
        # Parse request data
        data = json.loads(request.body)
        user_message = data.get('message', '').strip()
        
        if not user_message:
            return JsonResponse({'error': 'Message cannot be empty'}, status=400)
        
        # Save user message
        user_msg = GuidanceMessage.objects.create(
            session=session,
            message_type='user',
            content=user_message
        )
        
        # Get AI response
        ai_service = AIGuidanceService()
        if ai_service.is_available():
            user_context = ai_service.get_user_context(request.user)
            ai_response = ai_service.get_ai_response(user_message, session, user_context)
            
            # Update session timestamp
            session.updated_at = timezone.now()
            session.save()
            
            return JsonResponse({
                'success': True,
                'user_message': {
                    'id': user_msg.id,
                    'content': user_message,
                    'timestamp': user_msg.timestamp.isoformat(),
                },
                'ai_response': ai_response,
            })
        else:
            return JsonResponse({
                'error': 'AI service is currently unavailable'
            }, status=503)
            
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON data'}, status=400)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def session_list(request):
    """List all user's AI guidance sessions"""
    sessions = GuidanceSession.objects.filter(user=request.user)
    
    # Filter by guidance type if specified
    guidance_type = request.GET.get('type')
    if guidance_type and guidance_type in [choice[0] for choice in GuidanceSession.GUIDANCE_TYPES]:
        sessions = sessions.filter(guidance_type=guidance_type)
    
    # Search functionality
    search_query = request.GET.get('search')
    if search_query:
        sessions = sessions.filter(
            Q(title__icontains=search_query) |
            Q(initial_query__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(sessions, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'sessions': page_obj,
        'guidance_types': GuidanceSession.GUIDANCE_TYPES,
        'current_type': guidance_type,
        'search_query': search_query,
    }
    
    return render(request, 'ai_session_list.html', context)

@login_required
def preferences(request):
    """Manage user AI guidance preferences"""
    preferences, created = UserGuidancePreferences.objects.get_or_create(
        user=request.user
    )
    
    if request.method == 'POST':
        # Update preferences
        preferences.learning_style = request.POST.get('learning_style', '')
        preferences.academic_level = request.POST.get('academic_level', '')
        preferences.career_goals = request.POST.get('career_goals', '')
        preferences.response_length = request.POST.get('response_length', 'detailed')
        preferences.use_examples = request.POST.get('use_examples') == 'on'
        preferences.include_resources = request.POST.get('include_resources') == 'on'
        
        # Handle areas of interest (multi-select or comma-separated)
        areas_str = request.POST.get('areas_of_interest', '')
        if areas_str:
            areas = [area.strip() for area in areas_str.split(',') if area.strip()]
            preferences.areas_of_interest = areas
        else:
            preferences.areas_of_interest = []
        
        preferences.save()
        messages.success(request, 'Your preferences have been updated successfully!')
        return redirect('ai_guidance:preferences')
    
    context = {
        'preferences': preferences,
        'learning_styles': UserGuidancePreferences.LEARNING_STYLES,
    }
    
    return render(request, 'ai_preferences.html', context)

@login_required
def delete_session(request, session_id):
    """Delete an AI guidance session"""
    session = get_object_or_404(GuidanceSession, id=session_id, user=request.user)
    
    if request.method == 'POST':
        session.delete()
        messages.success(request, 'Session deleted successfully.')
        return redirect('ai_guidance:session_list')
    
    context = {'session': session}
    return render(request, 'ai_delete_session.html', context)

@login_required
def get_suggestions(request, guidance_type):
    """Get suggested questions for a guidance type (AJAX endpoint)"""
    ai_service = AIGuidanceService()
    suggestions = ai_service.get_suggested_questions(guidance_type)
    
    return JsonResponse({'suggestions': suggestions})
