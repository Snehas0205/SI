import os
import openai
import json
import logging
from django.conf import settings
from django.core.cache import cache
from .models import GuidanceSession, GuidanceMessage, UserGuidancePreferences

logger = logging.getLogger(__name__)

class AIGuidanceService:
    """Service class for handling AI-powered guidance"""
    
    def __init__(self):
        self.client = None
        if hasattr(settings, 'OPENAI_API_KEY') and settings.OPENAI_API_KEY:
            try:
                self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
            except Exception as e:
                logger.warning(f"OpenAI client initialization failed: {str(e)}")
                self.client = None
            
    def is_available(self):
        """Check if AI service is properly configured"""
        return self.client is not None and hasattr(settings, 'OPENAI_API_KEY') and settings.OPENAI_API_KEY
    
    def get_user_context(self, user):
        """Get user context for personalized guidance"""
        context = {
            'username': user.username,
            'is_student': hasattr(user, 'student_profile'),
            'is_teacher': hasattr(user, 'teacher_profile'),
        }
        
        # Get user preferences
        try:
            preferences = user.guidance_preferences
            context.update({
                'learning_style': preferences.learning_style,
                'academic_level': preferences.academic_level,
                'areas_of_interest': preferences.areas_of_interest,
                'career_goals': preferences.career_goals,
                'response_length': preferences.response_length,
                'use_examples': preferences.use_examples,
                'include_resources': preferences.include_resources,
            })
        except UserGuidancePreferences.DoesNotExist:
            # Set default preferences
            context.update({
                'learning_style': 'detailed',
                'response_length': 'detailed',
                'use_examples': True,
                'include_resources': True,
            })
        
        return context
    
    def create_system_prompt(self, guidance_type, user_context):
        """Create system prompt based on guidance type and user context"""
        base_prompt = """You are an AI educational assistant integrated into SmartEdu, 
        a comprehensive educational management system. Your role is to provide helpful, 
        accurate, and personalized guidance to students and teachers."""
        
        # Add user-specific context
        if user_context.get('is_student'):
            base_prompt += " You are currently helping a student."
        elif user_context.get('is_teacher'):
            base_prompt += " You are currently helping a teacher."
            
        if user_context.get('academic_level'):
            base_prompt += f" The user is at {user_context['academic_level']} level."
            
        if user_context.get('learning_style'):
            base_prompt += f" The user prefers {user_context['learning_style']} learning style."
        
        # Add guidance-specific instructions
        guidance_prompts = {
            'academic': """Focus on academic subjects, study techniques, understanding concepts, 
            homework help, and exam preparation. Provide clear explanations and examples.""",
            
            'career': """Provide career guidance, including career paths, skill development, 
            industry insights, job market trends, and professional development advice.""",
            
            'study': """Help with study planning, time management, learning strategies, 
            goal setting, and productivity techniques for academic success.""",
            
            'skill': """Assist with skill development, including technical skills, soft skills, 
            learning resources, practice exercises, and skill assessment.""",
            
            'general': """Provide general educational support, motivation, learning tips, 
            and answer questions about education and personal development."""
        }
        
        base_prompt += " " + guidance_prompts.get(guidance_type, guidance_prompts['general'])
        
        # Add response style preferences
        if user_context.get('response_length') == 'brief':
            base_prompt += " Keep responses concise and to the point."
        elif user_context.get('response_length') == 'comprehensive':
            base_prompt += " Provide detailed, comprehensive explanations."
            
        if user_context.get('use_examples'):
            base_prompt += " Include relevant examples when helpful."
            
        if user_context.get('include_resources'):
            base_prompt += " Suggest relevant learning resources when appropriate."
        
        return base_prompt
    
    def get_ai_response(self, user_message, session, user_context=None):
        """Get AI response for user message"""
        if not self.is_available():
            return "AI service is currently unavailable. Please check your API configuration."
        
        try:
            # Get conversation history
            messages = self.build_conversation_history(session, user_context)
            
            # Add current user message
            messages.append({
                "role": "user",
                "content": user_message
            })
            
            # Make API call
            response = self.client.chat.completions.create(
                model=getattr(settings, 'CAREER_AI_MODEL', 'gpt-3.5-turbo'),
                messages=messages,
                max_tokens=1000,
                temperature=0.7,
                top_p=0.9,
                frequency_penalty=0.1,
                presence_penalty=0.1
            )
            
            ai_response = response.choices[0].message.content
            
            # Store metadata
            metadata = {
                'model': response.model,
                'tokens_used': response.usage.total_tokens if hasattr(response, 'usage') else 0,
                'finish_reason': response.choices[0].finish_reason
            }
            
            # Save AI response to session
            GuidanceMessage.objects.create(
                session=session,
                message_type='ai',
                content=ai_response,
                metadata=metadata
            )
            
            return ai_response
            
        except Exception as e:
            logger.error(f"Error getting AI response: {str(e)}")
            return f"I apologize, but I encountered an error while processing your request. Please try again."
    
    def build_conversation_history(self, session, user_context=None):
        """Build conversation history for AI context"""
        messages = []
        
        # Add system prompt
        system_prompt = self.create_system_prompt(session.guidance_type, user_context or {})
        messages.append({
            "role": "system",
            "content": system_prompt
        })
        
        # Add conversation history (limit to last 10 messages for token efficiency)
        recent_messages = session.messages.all()[:10]
        
        for msg in recent_messages:
            role = "assistant" if msg.message_type == "ai" else "user"
            if msg.message_type != "system":  # Skip system messages in history
                messages.append({
                    "role": role,
                    "content": msg.content
                })
        
        return messages
    
    def analyze_user_query(self, query):
        """Analyze user query to determine guidance type and intent"""
        query_lower = query.lower()
        
        # Simple keyword-based classification
        if any(word in query_lower for word in ['career', 'job', 'profession', 'work', 'employment']):
            return 'career'
        elif any(word in query_lower for word in ['study', 'exam', 'test', 'homework', 'assignment']):
            return 'academic'
        elif any(word in query_lower for word in ['plan', 'schedule', 'time', 'organize', 'goal']):
            return 'study'
        elif any(word in query_lower for word in ['skill', 'learn', 'practice', 'improve', 'develop']):
            return 'skill'
        else:
            return 'general'
    
    def get_suggested_questions(self, guidance_type):
        """Get suggested questions based on guidance type"""
        suggestions = {
            'academic': [
                "How can I improve my understanding of mathematics?",
                "What are effective study techniques for science subjects?",
                "How should I prepare for upcoming exams?",
                "Can you help me with essay writing tips?"
            ],
            'career': [
                "What career options are available in technology?",
                "How can I develop skills for my chosen career?",
                "What should I include in my resume?",
                "How do I prepare for job interviews?"
            ],
            'study': [
                "How can I create an effective study schedule?",
                "What are some time management techniques for students?",
                "How do I stay motivated while studying?",
                "What's the best way to set academic goals?"
            ],
            'skill': [
                "What programming languages should I learn first?",
                "How can I improve my communication skills?",
                "What are some essential digital skills?",
                "How do I practice critical thinking?"
            ],
            'general': [
                "How can I become a better student?",
                "What are some tips for academic success?",
                "How do I balance studies with other activities?",
                "What resources can help me learn effectively?"
            ]
        }
        
        return suggestions.get(guidance_type, suggestions['general'])