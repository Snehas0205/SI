from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import json

class GuidanceSession(models.Model):
    """Model to store AI guidance sessions"""
    GUIDANCE_TYPES = [
        ('academic', 'Academic Guidance'),
        ('career', 'Career Guidance'), 
        ('study', 'Study Planning'),
        ('skill', 'Skill Development'),
        ('general', 'General Support'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='guidance_sessions')
    guidance_type = models.CharField(max_length=20, choices=GUIDANCE_TYPES, default='general')
    title = models.CharField(max_length=200)
    initial_query = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    
    # Store session metadata
    session_data = models.JSONField(default=dict, blank=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Guidance Session'
        verbose_name_plural = 'Guidance Sessions'
    
    def __str__(self):
        return f"{self.user.username} - {self.title}"

class GuidanceMessage(models.Model):
    """Model to store individual messages in a guidance session"""
    MESSAGE_TYPES = [
        ('user', 'User Message'),
        ('ai', 'AI Response'),
        ('system', 'System Message'),
    ]
    
    session = models.ForeignKey(GuidanceSession, on_delete=models.CASCADE, related_name='messages')
    message_type = models.CharField(max_length=10, choices=MESSAGE_TYPES)
    content = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)
    
    # Store additional data like AI model used, tokens, etc.
    metadata = models.JSONField(default=dict, blank=True)
    
    class Meta:
        ordering = ['timestamp']
        verbose_name = 'Guidance Message'
        verbose_name_plural = 'Guidance Messages'
    
    def __str__(self):
        return f"{self.session.title} - {self.message_type} at {self.timestamp}"

class UserGuidancePreferences(models.Model):
    """Model to store user preferences for AI guidance"""
    LEARNING_STYLES = [
        ('visual', 'Visual Learner'),
        ('auditory', 'Auditory Learner'),
        ('kinesthetic', 'Kinesthetic Learner'),
        ('reading', 'Reading/Writing Learner'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='guidance_preferences')
    learning_style = models.CharField(max_length=20, choices=LEARNING_STYLES, blank=True)
    academic_level = models.CharField(max_length=100, blank=True)  # e.g., "High School", "Undergraduate"
    areas_of_interest = models.JSONField(default=list, blank=True)  # List of subjects/topics
    career_goals = models.TextField(blank=True)
    
    # AI behavior preferences
    response_length = models.CharField(max_length=20, choices=[
        ('brief', 'Brief and Concise'),
        ('detailed', 'Detailed Explanations'),
        ('comprehensive', 'Comprehensive Analysis'),
    ], default='detailed')
    
    use_examples = models.BooleanField(default=True)
    include_resources = models.BooleanField(default=True)
    
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'User Guidance Preferences'
        verbose_name_plural = 'User Guidance Preferences'
    
    def __str__(self):
        return f"{self.user.username}'s Guidance Preferences"

class GuidanceResource(models.Model):
    """Model to store recommended resources from AI guidance"""
    RESOURCE_TYPES = [
        ('article', 'Article'),
        ('video', 'Video'),
        ('course', 'Online Course'),
        ('book', 'Book'),
        ('tool', 'Tool/Software'),
        ('website', 'Website'),
        ('exercise', 'Practice Exercise'),
    ]
    
    session = models.ForeignKey(GuidanceSession, on_delete=models.CASCADE, related_name='resources')
    resource_type = models.CharField(max_length=20, choices=RESOURCE_TYPES)
    title = models.CharField(max_length=300)
    description = models.TextField(blank=True)
    url = models.URLField(blank=True)
    
    # Additional metadata
    difficulty_level = models.CharField(max_length=20, choices=[
        ('beginner', 'Beginner'),
        ('intermediate', 'Intermediate'),
        ('advanced', 'Advanced'),
    ], blank=True)
    
    estimated_time = models.CharField(max_length=50, blank=True)  # e.g., "30 minutes", "2 hours"
    is_free = models.BooleanField(default=True)
    
    created_at = models.DateTimeField(default=timezone.now)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Guidance Resource'
        verbose_name_plural = 'Guidance Resources'
    
    def __str__(self):
        return f"{self.title} ({self.resource_type})"
