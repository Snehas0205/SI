from django.contrib import admin
from .models import GuidanceSession, GuidanceMessage, UserGuidancePreferences, GuidanceResource

@admin.register(GuidanceSession)
class GuidanceSessionAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'guidance_type', 'created_at', 'updated_at', 'is_active')
    list_filter = ('guidance_type', 'is_active', 'created_at')
    search_fields = ('title', 'user__username', 'initial_query')
    readonly_fields = ('created_at', 'updated_at')
    
    fieldsets = (
        (None, {
            'fields': ('user', 'guidance_type', 'title', 'initial_query', 'is_active')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
        ('Session Data', {
            'fields': ('session_data',),
            'classes': ('collapse',)
        }),
    )

@admin.register(GuidanceMessage)
class GuidanceMessageAdmin(admin.ModelAdmin):
    list_display = ('session', 'message_type', 'content_preview', 'timestamp')
    list_filter = ('message_type', 'timestamp', 'session__guidance_type')
    search_fields = ('content', 'session__title', 'session__user__username')
    readonly_fields = ('timestamp',)
    
    def content_preview(self, obj):
        return obj.content[:100] + "..." if len(obj.content) > 100 else obj.content
    content_preview.short_description = 'Content Preview'
    
    fieldsets = (
        (None, {
            'fields': ('session', 'message_type', 'content')
        }),
        ('Metadata', {
            'fields': ('timestamp', 'metadata'),
            'classes': ('collapse',)
        }),
    )

@admin.register(UserGuidancePreferences)
class UserGuidancePreferencesAdmin(admin.ModelAdmin):
    list_display = ('user', 'learning_style', 'academic_level', 'response_length', 'created_at')
    list_filter = ('learning_style', 'response_length', 'use_examples', 'include_resources')
    search_fields = ('user__username', 'academic_level', 'career_goals')
    readonly_fields = ('created_at', 'updated_at')
    
    fieldsets = (
        ('User Info', {
            'fields': ('user', 'learning_style', 'academic_level', 'career_goals')
        }),
        ('AI Behavior', {
            'fields': ('response_length', 'use_examples', 'include_resources')
        }),
        ('Areas of Interest', {
            'fields': ('areas_of_interest',),
            'description': 'JSON list of subjects/topics the user is interested in'
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(GuidanceResource)
class GuidanceResourceAdmin(admin.ModelAdmin):
    list_display = ('title', 'resource_type', 'session', 'difficulty_level', 'is_free', 'created_at')
    list_filter = ('resource_type', 'difficulty_level', 'is_free', 'created_at')
    search_fields = ('title', 'description', 'session__title')
    readonly_fields = ('created_at',)
    
    fieldsets = (
        (None, {
            'fields': ('session', 'resource_type', 'title', 'description', 'url')
        }),
        ('Details', {
            'fields': ('difficulty_level', 'estimated_time', 'is_free')
        }),
        ('Timestamp', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )
