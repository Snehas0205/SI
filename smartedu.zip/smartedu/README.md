# SmartTrack - Smart Educational Attendance and Career Guidance System

SmartTrack is a comprehensive Django-based web application that combines intelligent attendance tracking with personalized career guidance for educational institutions.

## Features

### 🎯 Attendance Management
- **Multi-modal Attendance Tracking**: QR Code, Bluetooth, WiFi, Face ID, and manual methods
- **Real-time Session Management**: Teachers can create and manage attendance sessions
- **Automated Analytics**: Detailed attendance reports and goal tracking
- **Smart Scheduling**: Integration with class schedules and timetables

### 🚀 Career Guidance System
- **Personalized Task Recommendations**: AI-powered task suggestions during free time
- **Career Path Exploration**: Comprehensive career guidance based on academic performance
- **Skill Development Tracking**: Monitor and develop technical and soft skills
- **Achievement System**: Gamified learning with badges and rewards
- **Free Time Optimization**: Smart suggestions for productive activities

### 👥 User Management
- **Multi-role Support**: Students, Teachers, and Administrators
- **Profile Management**: Comprehensive user profiles with career preferences
- **Dashboard Views**: Role-specific dashboards with relevant information

## Project Structure

```
smartedu/
├── attendance/          # Attendance tracking app
│   ├── models.py       # User profiles, subjects, sessions, attendance
│   ├── views.py        # Authentication, dashboard, attendance marking
│   ├── urls.py         # Attendance-related URLs
│   └── admin.py        # Admin interface configuration
├── career/             # Career guidance app
│   ├── models.py       # Career paths, skills, tasks, achievements
│   ├── views.py        # Career dashboard, profile, task management
│   ├── urls.py         # Career-related URLs
│   └── admin.py        # Admin interface configuration
├── templates/          # HTML templates
│   ├── base.html       # Base template
│   ├── home.html       # Landing page
│   ├── login.html      # Login page
│   ├── *_dashboard.html # Role-specific dashboards
│   └── career/         # Career-related templates
├── static/             # Static files (organized by type)
│   ├── css/           # Stylesheets only
│   ├── js/            # JavaScript files only
│   └── images/        # Image assets
├── smarttrack/         # Django project settings
├── manage.py          # Django management script
├── requirements.txt   # Python dependencies
└── create_demo_data.py # Demo data creation script
```

## Setup Instructions

### 1. Environment Setup
```bash
# Navigate to project directory
cd E:\dev\smartedu

# Activate virtual environment
smarttrack_env\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Database Setup
```bash
# Apply migrations
python manage.py migrate

# Create superuser (if needed)
python manage.py createsuperuser

# Populate with demo data
python create_demo_data.py
```

### 3. Static Files
```bash
# Collect static files
python manage.py collectstatic --noinput
```

### 4. Run Development Server
```bash
python manage.py runserver 127.0.0.1:8000
```

## Demo Credentials

The system comes with pre-configured demo users:

- **Student Account**
  - Username: `student`
  - Password: `password123`
  - Access: Student dashboard, attendance tracking, career guidance

- **Teacher Account**
  - Username: `teacher`
  - Password: `password123`
  - Access: Teacher dashboard, session management, attendance reports

- **Admin Account**
  - Username: `admin`
  - Password: [your admin password]
  - Access: Full system administration

## Key URLs

- **Home Page**: `http://127.0.0.1:8000/`
- **Login**: `http://127.0.0.1:8000/login/`
- **Dashboard**: `http://127.0.0.1:8000/dashboard/`
- **Admin Panel**: `http://127.0.0.1:8000/admin/`
- **Attendance Reports**: `http://127.0.0.1:8000/attendance/reports/`
- **Career Guidance**: `http://127.0.0.1:8000/career/`

## Technology Stack

- **Backend**: Django 5.2.6
- **Database**: SQLite (development)
- **Frontend**: Bootstrap 5.3.2, HTML5, CSS3, JavaScript
- **Icons**: Font Awesome 6.4.0
- **QR Code Generation**: qrcode library with Pillow
- **Authentication**: Django's built-in authentication system

## File Organization Rules

This project follows strict file organization rules:

- **Templates folder** (`templates/`): Contains **only HTML files**
- **CSS folder** (`static/css/`): Contains **only CSS files**
- **JavaScript folder** (`static/js/`): Contains **only JavaScript files**

This ensures clean separation of concerns and easy maintenance.

## Development Notes

### Models Overview

**Attendance App:**
- `UserProfile`: Extended user information with role-based access
- `Subject`: Academic subjects with teacher-student relationships
- `ClassSchedule`: Weekly class schedules
- `AttendanceSession`: Individual attendance tracking sessions
- `Attendance`: Attendance records with status and timing
- `AttendanceGoal`: Student attendance goals and progress

**Career App:**
- `CareerPath`: Available career paths and descriptions
- `Skill`: Skills required for different careers
- `StudentCareerProfile`: Individual student career preferences
- `PersonalizedTask`: AI-recommended tasks for students
- `FreeTimeActivity`: Tracking of student free time usage
- `AchievementBadge`: Gamification elements

### Key Features

1. **Attendance Tracking**: Multiple methods for marking attendance
2. **Career Guidance**: Personalized recommendations based on academic performance
3. **Task Management**: Smart task suggestions during free periods
4. **Analytics**: Comprehensive reporting and progress tracking
5. **Gamification**: Achievement system to encourage engagement

## Contributing

When contributing to this project, please maintain the file organization rules and ensure all templates, CSS, and JavaScript files are properly separated into their respective directories.

## License

This project is developed for educational purposes. Please ensure appropriate licensing for production use.

---

**SmartTrack** - Transforming Education Through Intelligent Attendance and Career Guidance